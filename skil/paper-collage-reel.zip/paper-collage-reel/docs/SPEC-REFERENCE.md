# Scene spec reference (YAML)

**Where the spec lives.** In the project folder made by `tools/new_project.py`: `<project>/scenes/<name>.yml`. Paths inside a spec are relative to the spec file, so from `scenes/` the brand is `brand: ../brand.yml` and a hero picture is `../cutouts/dog-center.png`. Run every command from the skill folder with its own Python (`.venv/bin/python` on macOS/Linux, `.venv\Scripts\python.exe` on Windows).

One YAML file describes the whole reel. Check it with `python tools/preview_scene.py spec.yml` (prints RULE CHECKS, writes a motion strip), render it with `python tools/render.py spec.yml out.mp4 --voice voice.wav`.
Coordinates are pixels of the 1080 x 1920 frame; (0, 0) is the top-left corner. Times are seconds.

## Top level
| key | meaning |
|---|---|
| `brand` | path to a `brand.yml`, relative to the spec file (or absolute) |
| `heroes` | `{name: {pose: file}}`: cut-out pictures of the hero, one file per pose (paths relative to the spec). The hero can be any cut-out: a head only (the demo picture is a head) or a whole animal. A head-only hero needs the body as a separate `image` in the same `group`. A `file.json` next to a PNG (written by `tools/cutout.py head`) holds the face axis so the head sits straight |
| `sfx` | `none` (default) or `auto` (a soft pop when a hero, heart, folder or plate arrives, a whoosh when a bird flies) |
| `music` | `synth` (default: original quiet track), `none`, or a path to the user's own audio file |
| `scenes` | list of scenes, in time order, contiguous (each starts where the previous ends, the first starts at 0) |

## Scene
| key | meaning |
|---|---|
| `id` | unique name |
| `start`, `end` | seconds on the voice timeline (from `tools/plan_scenes.py`, approved by the user) |
| `background` | `{type: crumpled\|gingham\|sky\|solid, color: <brand colour or #hex>, cell: 72 (gingham), seed: 3}`. Default: crumpled paper in `light` |
| `transition` | `cut` = hard cut into this scene. Default is a torn-paper wipe of 0.18 s centred on `start`. Use `cut` where the speech has no silence at the boundary |
| `sfx` | explicit effects: `[{at: 0.1, kind: pop\|whoosh\|snip\|stamp\|type\|page, gain: 0.5}]` (`at` relative to the scene) |
| `elements` | list of elements, drawn in list order (or by `z`) |

## Elements: keys every element has
| key | default | meaning |
|---|---|---|
| `type` | required | see the table below |
| `id` | `<scene>-<index>` | name used in messages |
| `at` | 0.1 | when it appears, seconds after the scene start |
| `until` | never | when it disappears (a hard cut-out; must be after `at`) |
| `kind` | `pop` | how it arrives: `pop` (scale-in 0.30 s), `appear` (fade 0.12 s, no scaling), `drop` (falls and bounces, 0.5 s), `slide_l` / `slide_r` (0.36 s), `rise` (0.26 s), `fly` (see bird). A hero defaults to `appear`, a caption to `rise` |
| position | `x: 0, y: 0` | **one of:** `x`, `y` = top-left of the content box; `center: [x, y]`; `bottom_center: [x, y]` (use it for heroes and anything standing on something). The white paper edge and shadow are drawn OUTSIDE this box |
| `z` | list index | stacking order, higher on top |
| `group` | none | elements with the same group appear together without scaling, share the same jitter and never drift apart. Put a hero and the body piece under its head in one group |
| `edge` | 8 for `image`, 0 otherwise | width of the white paper border in px. `torn: true` makes it hand-torn. `shadow: [dx, dy]` |
| `bleed` | false | `true` exempts the element from the 60 px edge-margin check (use only for deliberate bleed) |

Colours are brand names (`dark`, `light`, `soft`, `white`, `accent`, `muted`) or `#rrggbb`. Keep `accent` for ONE highlighted word on a caption.

## Element types
The skill ships no premade stickers. Pictures of things are `image` elements (real cut-outs the user approved). Paper furniture (`sheet`, `label`, `tape`, `caption`, `bubble`) and `heart` are drawn by the engine. The drawn pictorial types `plate`, `fork`, `knife`, `folder`, `bird`, `note`, `star`, `burst` are last-resort fallbacks for when no real picture can be found and the user agrees.

| type | keys |
|---|---|
| `image` | `file` (transparent PNG cut-out), `w` or `h` (keeps proportions), `rot` |
| `hero` | `hero` (name from `heroes`), `h` (height in px, one scale for all poses), `poses: [{pose, at, mirror}]` (`mirror` defaults to false and flips the picture left-right: the same pose with `mirror: true` is how to look the other way. A pose switch is instant at `at`; sorted by `at`, the last pose is held, each pose+mirror pair at most once, max 5), `bottom_center` or `center` |
| `caption` | `text`, `accent` (a substring of `text` drawn on the accent plate), `font_size` (42), `y` (default: `safe_zone.bottom + 5`), `rot`, `word` (the spoken word it belongs to: the caption may not appear before it, needs `--words`). Centred horizontally |
| `label` | `text`, `font` (`display`, `subtitle`, `label`), `font_size`, `fill`, `color`, `rot`, `pad: [x, y]` |
| `sheet` | `size: [w, h]`, `color`, `seed`: a torn crumpled sheet with a white border |
| `tape` | `w`, `h`, `rot`: one strip per print, on a corner or the top edge |
| `plate` | `r` (radius, the picture is 2r+20 px), `rim` (colour of the rim pattern, default `dark`). To put a hero on it, its `bottom_center` y must lie inside the plate (the plate is a container: no overlap check) |
| `fork`, `knife` | `h` |
| `folder` | `label`, `w`, `h`, `font_size` |
| `bubble` | `text`, `font_size`, `fill`, `color`, `tail: left\|right` |
| `heart` | `size`, `color`, `beat: true` (alternates two sizes every 2 frames), `edge` |
| `bird` | `size`, `colors: {body, wing, belly}`, `flip` (default: flipped when it flies left), and with `kind: fly`: the bird's `center` is where it comes to rest; `from: [dx, dy]` is the start offset from that point, `out: [dx, dy]` is the offset from that point where it has left the frame, `dur` is the flight time in seconds (default 1.05, the arrival counts as finished at `at + dur`) |
| `burst`, `star`, `note` | `size`, `color` (`points` for burst) |

## Rules the tools check (codes for `--skip code`, `--skip code:scene-id`, several separated by commas)
A beating heart is idle motion: it does not count for `arrival` or `hold`. Errors raised when the spec is loaded (a pose used twice, a missing glyph in the font, a caption accent not in its text, a bad `until`) have no skip code: fix the spec.

`count` more than 6 elements · `arrival` the last element arrives after the first half of the scene · `hold` the finished picture holds less than 0.8 s · `exit-late` something disappears in the last 0.3 s · `margin` content closer than 60 px to the edge · `overlap` two elements overlap (containers like plate, sheet, folder, burst are exempt) · `caption-zone` caption below `safe_zone.caption_bottom` · `reading-speed` more than 3 words per second · `caption-early` / `caption-word` caption before its word, or the word is not in the transcript · `head-gap` the head ends more than 10 px above the body piece in its group · `timeline` scenes not contiguous, not starting at 0, or duplicate ids · `wipe-word` a wipe falls on a spoken word (use `transition: cut`).

## A complete small example (the tests load this block)
```yaml
brand: ../../presets/default/brand.yml
heroes:
  demo: {center: hero-center.png}
scenes:
  - id: intro
    start: 0
    end: 2.4
    background: {type: gingham, color: soft}
    elements:
      - {type: plate, r: 400, center: [540, 760], at: 0.04}
      - type: hero
        hero: demo
        h: 520
        bottom_center: [540, 960]
        at: 0.3
        poses:
          - {pose: center, at: 0.3, mirror: true}
          - {pose: center, at: 0.9}
      - {type: heart, size: 220, beat: true, center: [540, 1060], at: 1.2}
      - {type: caption, text: "HELLO WORLD", accent: "WORLD", at: 0.2}
  - id: outro
    start: 2.4
    end: 4.8
    background: {type: sky}
    elements:
      - {type: folder, label: "TIP", w: 720, h: 520, x: 180, y: 820, at: 0.05}
      - {type: bird, size: 300, center: [250, 700], at: 0.15, kind: fly, from: [260, 300], out: [-800, -1000], dur: 0.85}
      - {type: caption, text: "THE END", accent: "END", at: 0.3}
```
