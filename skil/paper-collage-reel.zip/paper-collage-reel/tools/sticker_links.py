"""Print search links (no network, nothing is downloaded) so the USER can collect a sticker picture herself.
usage: python tools/sticker_links.py "tennis ball" ["dog bone" ...]
The user chooses and saves the pictures into <project>/stickers/raw/. A plain background makes the cut-out cleaner: add the words 'white background' to the search."""
import sys, urllib.parse
SITES = [('Pexels', 'https://www.pexels.com/search/{q}/'), ('Unsplash', 'https://unsplash.com/s/photos/{q}'), ('Pixabay', 'https://pixabay.com/images/search/{q}/'),
         ('Openverse (CC0 / public domain filter inside)', 'https://openverse.org/search/image?q={q}'), ('Pinterest (style ideas; check the right to use before cutting)', 'https://www.pinterest.com/search/pins/?q={q}')]
def main():
    if len(sys.argv) < 2 or sys.argv[1] in ('-h', '--help'): print(__doc__); sys.exit(0 if len(sys.argv) > 1 else 1)
    for q in sys.argv[1:]:
        print(f'\n{q}  (tip: also try "{q} white background" or "{q} isolated")')
        for name, u in SITES: print(f'  {name}: ' + u.format(q=urllib.parse.quote(q)))
if __name__ == '__main__': main()
