"""Prepare a critic review of a rendered video (approval gates 3 and 4). Extracts frames, finds static stretches, writes critic-brief.md.
usage: python tools/critic_pack.py video.mp4 out_dir --wanted wanted.txt --rejected rejected.txt [--spec spec.yml] [--fps 5]
wanted.txt / rejected.txt: one item per line, in the user's words. Both are required and are printed back: an earlier critic received them
swapped and produced wrong findings (MISTAKES #18). Then start a SEPARATE agent, give it the text of critic-brief.md, and fix what it finds (max 2 rounds)."""
import shutil, subprocess, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine import video

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

def lines(p):
    t = [l.strip() for l in Path(p).read_text(encoding='utf-8').splitlines() if l.strip() and not l.strip().startswith('#')]
    if not t: raise SystemExit(f'{p} is empty: write what the user wants / rejects, one item per line')
    return t

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    if len(sys.argv) < 3 or not arg('--wanted') or not arg('--rejected'): print(__doc__); sys.exit(1)
    mp4, out = Path(sys.argv[1]), Path(sys.argv[2]); fps = float(arg('--fps', 5)); info = video.probe(mp4)
    wanted, rejected = lines(arg('--wanted')), lines(arg('--rejected'))
    fr = out / 'frames'; shutil.rmtree(fr, ignore_errors=True); fr.mkdir(parents=True)
    subprocess.run([video.ffmpeg_path(), '-v', 'error', '-i', str(mp4), '-vf', f'fps={fps},scale=360:640', '-q:v', '3', str(fr / 'f%04d.jpg')], check=True)
    files = sorted(fr.glob('f*.jpg')); n = len(files)
    # contact sheets: 40 frames each (8 x 5), labelled with the time
    cols, rows = 8, 5; sheets = []
    for s0 in range(0, n, cols * rows):
        sh = Image.new('RGB', (cols * 216, rows * 384), 'white')
        for k, f in enumerate(files[s0:s0 + cols * rows]):
            im = Image.open(f).resize((216, 384)); ImageDraw.Draw(im).rectangle([0, 0, 216, 14], fill=(0, 0, 0)); ImageDraw.Draw(im).text((3, 1), f'{(s0 + k) / fps:.2f}s', fill='white'); sh.paste(im, ((k % cols) * 216, (k // cols) * 384))
        p = out / f'sheet-{s0 // (cols * rows) + 1:02d}.png'; sh.save(p); sheets.append(p)
    # motion: mean absolute difference between consecutive sampled frames; long runs of almost no change = dead picture
    small = [np.array(Image.open(f).convert('L').resize((90, 160))).astype(float) for f in files]; d = [float(np.abs(small[i + 1] - small[i]).mean()) for i in range(n - 1)]
    static, run0 = [], None
    for i, v in enumerate(d + [99]):
        if v < 0.6 and run0 is None: run0 = i
        if v >= 0.6 and run0 is not None:
            if (i - run0) / fps >= 1.5: static.append((run0 / fps, i / fps))
            run0 = None
    rules = (ROOT / 'MISTAKES.md').read_text(encoding='utf-8')
    brief = f"""# Critic brief

You are a harsh critic of a vertical paper-collage reel. No praise. Do NOT edit any file. Watch the VIDEO through the frames, not stills of the final state.
Video: {mp4} ({info['width']}x{info['height']}, {info['duration']:.1f}s). Frames at {fps:g} per second: {fr} (f0001.jpg = 0.00s, then every {1 / fps:.2f}s).
Contact sheets (40 frames each, time-labelled): {', '.join(str(p) for p in sheets)}. Read them with the Read tool, then zoom into single frames where something looks wrong.

## The user WANTS (keep, do not criticise these)
{chr(10).join('- ' + w for w in wanted)}

## The user REJECTED (report every occurrence)
{chr(10).join('- ' + r for r in rejected)}

## Automatic motion measurement
Stretches of 1.5 s or more with almost no change (possible dead picture): {', '.join(f'{a:.1f}-{b:.1f}s' for a, b in static) or 'none'}.

## What to judge, scene by scene
1. Is the key action finished early (first half of the scene) and then held for 0.8 s or more? Is anything still arriving when the next scene wipes in?
2. Does the picture match the words at that moment (captions never before the word)?
3. Head on the neck of the body, no gap or drift while arriving or switching poses? Expression changes scripted and held, no unexpected open mouth?
4. Anything cropped by the frame edge, overlapping, too small to read, or in the caption zone? Tape, ribbon, bow placed correctly?
5. The same hero object repeated in several scenes? Too many elements at once?

## Output
Numbered defects, ranked P0 (blocks showing) and P1, each with a timestamp (seconds), what is wrong, and a concrete fix. End with the verdict: SHOW or FIX FIRST. Be concise.

## The rules of this skill (MISTAKES.md)
{rules}
"""
    (out / 'critic-brief.md').write_text(brief, encoding='utf-8')
    print(f'WANTED ({len(wanted)}):'); [print('  + ' + w) for w in wanted]; print(f'REJECTED ({len(rejected)}):'); [print('  - ' + r) for r in rejected]
    print(f'\n{n} frames, {len(sheets)} contact sheets, static stretches: {static or "none"}\nBrief: {out / "critic-brief.md"}\nCheck the two lists above are the right way round, then give the brief to a separate critic agent.')

if __name__ == '__main__': main()
