"""Render the final mp4 (approval gate 4). Refuses to render while rule checks fail.
usage: python tools/render.py spec.yml out.mp4 [--voice voice.wav] [--music synth|none|file.wav] [--words words.json] [--skip code,code:scene-id] [--force]
Codes: count arrival hold exit-late margin overlap caption-zone reading-speed caption-early caption-word head-gap timeline wipe-word
An existing out.mp4 is never overwritten without --force (keep every version: -v1, -v2). Skipped checks are logged in out.mp4.log.json.
The voice is only converted to 48 kHz mono and mixed at gain 1.0 (never processed)."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine.render import render, RuleViolations

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    words = json.loads(Path(arg('--words')).read_text(encoding='utf-8'))['words'] if arg('--words') else None
    try: out = render(sys.argv[1], sys.argv[2], arg('--voice'), arg('--music'), tuple((arg('--skip') or '').split(',')) if arg('--skip') else (), words, force='--force' in sys.argv)
    except RuleViolations as e: print(e); sys.exit(2)
    except (FileExistsError, ValueError, RuntimeError) as e: print(e); sys.exit(3)
    from engine import video
    print('rendered', out, video.probe(out))

if __name__ == '__main__': main()
