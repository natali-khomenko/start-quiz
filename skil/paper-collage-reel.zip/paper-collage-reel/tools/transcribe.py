"""Word-level transcript of the voice recording (local, faster-whisper). Scene cuts and caption timing come from it.
usage: python tools/transcribe.py voice.wav words.json [--lang uk] [--model small] [--prompt "script text and brand names"]
Always pass --lang when you know it (auto-detect looks at the first 30 s only).
First run downloads the speech model once (tiny ~75 MB, small ~480 MB). Output: {"language","duration","words":[{"word","start","end"}]}"""
import json, sys
from pathlib import Path

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

SIZES = {'tiny': '75 MB', 'base': '145 MB', 'small': '480 MB', 'medium': '1.5 GB'}

def transcribe(path, lang=None, model='small', prompt=None):
    """prompt: the script text and the brand or product names (spelling hints for the speech model)."""
    from faster_whisper import WhisperModel
    print(f"loading speech model '{model}' (first run downloads about {SIZES.get(model, '?')} once; needs internet only that time)")
    m = WhisperModel(model, device='cpu', compute_type='int8')
    segs, info = m.transcribe(str(path), language=lang, word_timestamps=True, vad_filter=False, condition_on_previous_text=False, initial_prompt=prompt)
    words = []
    for s in segs:
        for w in (s.words or []):
            t = w.word.strip()
            if t and w.end >= w.start and (not words or w.start >= words[-1]['start'] - 0.01): words.append({'word': t, 'start': round(w.start, 3), 'end': round(w.end, 3)})
    if lang is None and info.language_probability < 0.8: print(f'WARNING: language guessed as {info.language} with probability {info.language_probability:.2f}: pass --lang explicitly (uk, en, ...)')
    return {'language': info.language, 'language_probability': round(info.language_probability, 3), 'duration': round(info.duration, 3), 'words': words}

if __name__ == '__main__':
    if len(sys.argv) < 3 or '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0 if ('-h' in sys.argv or '--help' in sys.argv) else 1)
    r = transcribe(sys.argv[1], arg('--lang'), arg('--model', 'small'), arg('--prompt')); Path(sys.argv[2]).write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f"{len(r['words'])} words, language {r['language']} ({r['language_probability']}), {r['duration']}s -> {sys.argv[2]}")
    print('Names and brand words are often misheard: read the words and agree the spelling with the user (MISTAKES #20).')
