"""Render a motion strip of one scene (approval gate 3: look at MOTION, not at the end state).
usage: python tools/preview_scene.py spec.yml [--scene ID] [--step 0.25 | --times 0.1,0.4,0.8] [--out strip.png] [--cols 8]
Default frames: every 0.1 s over the first 0.5 s, 0.2 s after every element and every hero pose change (so each event is visible), 40/60/80% of the scene, and the last 0.3 s and 0.05 s.
--step S: a frame every S seconds instead. Without --scene all scenes are shown. Prints RULE CHECKS first."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine.scene import Spec

def arg(n, d=None): return sys.argv[sys.argv.index(n) + 1] if n in sys.argv else d

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    spec = Spec(sys.argv[1]); bad = spec.check()
    print('RULE CHECKS: ' + ('all passed' if not bad else f'{len(bad)} violation(s)')); [print('  - ' + v) for v in bad]
    sid = arg('--scene'); scenes = [spec.scene(sid)] if sid else spec.scenes; cols = int(arg('--cols', 8)); cw, ch = 216, 384
    rows = []
    for sc in scenes:
        dur = sc.end - sc.start
        if arg('--times'): ts = [float(x) for x in arg('--times').split(',')]
        elif arg('--step'): ts = [round(k * float(arg('--step')), 3) for k in range(1, int(dur / float(arg('--step'))) + 1)] + [round(dur - 0.05, 2)]
        else:
            ev = [L.at + 0.2 for L in sc.layers] + [at_ + 0.15 for L in sc.layers if L.cycle == 'poses' for at_, _ in L.imgs]
            ts = sorted(set([round(0.1 * k, 2) for k in range(1, 6)] + [round(x, 2) for x in ev if x < dur] + [round(dur * q, 2) for q in (.4, .6, .8)] + [round(dur - 0.3, 2), round(dur - 0.05, 2)]))
        rows.append((sc, [t for t in ts if 0 <= t < dur]))
    n = sum(len(r[1]) for r in rows); R = (n + cols - 1) // cols; sheet = Image.new('RGB', (cols * cw, R * ch), 'white'); i = 0
    for sc, ts in rows:
        for t in ts:
            fr = sc.frame(sc.start + t).convert('RGB').resize((cw, ch)); ImageDraw.Draw(fr).rectangle([0, 0, cw, 14], fill=(0, 0, 0)); ImageDraw.Draw(fr).text((3, 1), f'{sc.id} {t:.2f}s', fill='white')
            sheet.paste(fr, ((i % cols) * cw, (i // cols) * ch)); i += 1
    out = arg('--out', str(ROOT / 'tests' / 'out' / 'strip.png')); Path(out).parent.mkdir(parents=True, exist_ok=True); sheet.save(out); print(out)

if __name__ == '__main__': main()
