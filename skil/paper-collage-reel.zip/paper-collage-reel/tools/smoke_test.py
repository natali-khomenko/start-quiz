"""5-second demo collage proving the whole stack works: brand fonts, paper look, animation, ffmpeg, audio mux.
usage: python tools/smoke_test.py [--brand presets/natali/brand.yml]"""
import math, shutil, sys, tempfile, wave
from pathlib import Path
import numpy as np
from PIL import Image
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine import W, H
from engine.brand import Brand
from engine import paper, video

def ease_out_back(u, c=1.9): u -= 1; return 1 + (c + 1) * u ** 3 + c * u ** 2

def build_demo(brand, workdir, seconds=5.0, fps=12):
    bg = paper.crumpled((W, H), brand.color('light'), 3, 22)
    sheet = paper.sheet((900, 1100), brand.color('soft'))
    title = paper.label('paper collage', brand.font('display', 90), color=brand.color('dark'), rot=-3, pad=(40, 26))
    cap = paper.label('IT WORKS', brand.font('subtitle', 44), color=brand.color('dark'), accent=(3, 8), accent_color=brand.color('accent'), pad=(34, 20), rot=-1)
    note = paper.label('Привіт! Це тест', brand.font('label', 48), color=brand.color('dark'), rot=2)   # Cyrillic check
    hearts = [paper.with_edge(paper.heart(s, c), 8, False) for s, c in [(240, brand.color('accent')), (160, brand.color('dark')), (120, brand.color('soft'))]]
    tape = paper.tape(250, 70, -32)
    items = [(sheet, (90, 300), 0.10), (tape, (60, 280), 0.35), (title, (110, 420), 0.55), (note, (300, 760), 0.95),
             (hearts[0], (420, 900), 1.30), (hearts[1], (200, 1120), 1.65), (hearts[2], (760, 1060), 2.00), (cap, (W // 2 - cap.width // 2, 1405), 2.40)]
    frames = Path(workdir) / 'frames'; shutil.rmtree(frames, ignore_errors=True); frames.mkdir(parents=True)
    n = int(seconds * fps)
    for k in range(n):
        t = k / fps; f = bg.copy()
        for im, pos, t0 in items:
            d = t - t0
            if d < 0: continue
            u = min(1, d / 0.30); s = .55 + .45 * ease_out_back(u); w, h = im.size
            r = im.resize((max(1, int(w * s)), max(1, int(h * s))), Image.BILINEAR) if s != 1 else im
            f.alpha_composite(r, (int(pos[0] + (w - r.width) / 2), int(pos[1] + (h - r.height) / 2)))
        f.convert('RGB').save(frames / f'f{k:05d}.png', compress_level=1)
    return frames

def make_audio(path, seconds=5.0, sr=48000):
    t = np.arange(int(seconds * sr)) / sr; x = np.zeros_like(t)
    for t0 in (0.10, 0.55, 1.30, 2.40):
        i = int(t0 * sr); m = int(.10 * sr); tt = np.arange(m) / sr; x[i:i + m] += np.sin(2 * np.pi * (700 * np.exp(-tt * 20) + 160) * tt) * np.exp(-tt * 40) * .5
    with wave.open(str(path), 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((x * 32767).astype(np.int16).tobytes())

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    bp = sys.argv[sys.argv.index('--brand') + 1] if '--brand' in sys.argv else None
    brand = Brand(bp); print(f'brand: {brand.name}')
    assert brand.has_glyphs('label', 'Привіт'), 'label font lacks Cyrillic'
    out_dir = ROOT / 'tests' / 'out'; out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        frames = build_demo(brand, tmp); make_audio(Path(tmp) / 'a.wav')
        out = video.encode(frames, out_dir / 'smoke.mp4', 12, 24, Path(tmp) / 'a.wav')
        first = np.array(Image.open(frames / 'f00000.png')).astype(float); last = np.array(Image.open(frames / f'f{len(list(frames.glob("*.png"))) - 1:05d}.png')).astype(float)
    info = video.probe(out)
    assert (info['width'], info['height']) == (1080, 1920), info
    assert 4.5 < info['duration'] < 5.6, info
    assert info['has_audio'], 'audio missing'
    assert np.abs(last - first).mean() > 5, 'animation produced no change between first and last frame'
    print(f'SMOKE TEST OK -> {out}  ({info["width"]}x{info["height"]}, {info["duration"]:.1f}s, audio: yes)')

if __name__ == '__main__': main()
