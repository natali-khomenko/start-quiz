"""Environment check: python, packages, ffmpeg, fonts, optional models. Exit code 0 only if everything required works.
usage: python tools/doctor.py [--models]   (--models pre-downloads the cut-out model, ~170 MB, with your consent)"""
import importlib, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
ok = True
def check(name, cond, hint=''):
    global ok
    print(('  OK   ' if cond else '  FAIL ') + name + ('' if cond else f'  -> {hint}')); ok = ok and cond
print('paper-collage-reel doctor')
check(f'python {sys.version.split()[0]} (need 3.9+)', sys.version_info >= (3, 9), 'install Python 3.12')
for mod, pip in [('PIL', 'pillow'), ('numpy', 'numpy'), ('scipy', 'scipy'), ('skimage', 'scikit-image'), ('yaml', 'pyyaml'), ('rembg', 'rembg'), ('onnxruntime', 'onnxruntime'), ('faster_whisper', 'faster-whisper')]:
    try: importlib.import_module(mod); check(f'package {pip}', True)
    except Exception as e: check(f'package {pip}', False, f'run setup again ({type(e).__name__})')
ff = shutil.which('ffmpeg'); check('ffmpeg on PATH', bool(ff), 'macOS: brew install ffmpeg | Windows: winget install Gyan.FFmpeg')
if ff:
    try: check('ffmpeg can encode H.264 (libx264)', 'libx264' in subprocess.run([ff, '-hide_banner', '-encoders'], capture_output=True, text=True).stdout, 'install a full ffmpeg build')
    except Exception as e: check('ffmpeg runs', False, str(e))
from engine.brand import Brand
b = Brand()
for role in ('display', 'subtitle', 'label'):
    check(f'font {role}', b.has_glyphs(role, 'Aa1') , 'font file missing in assets/fonts')
check('Cyrillic glyphs in label font', b.has_glyphs('label', 'Абвгґдеєжзиіїйклмнопрстуфхцчшщьюя'), 'choose a font with Cyrillic support in brand.yml')
if '--models' in sys.argv:
    print('Downloading cut-out model (one time, ~170 MB)...')
    from rembg import new_session; new_session('isnet-general-use'); check('cut-out model ready', True)
print('\nALL GOOD' if ok else '\nSOMETHING IS MISSING: fix the FAIL lines above, then run doctor again.')
sys.exit(0 if ok else 1)
