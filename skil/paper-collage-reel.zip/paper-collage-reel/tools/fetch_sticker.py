"""Download ONE picture the user has approved, and log it in SOURCES.tsv. Refuses to run without --approved-by-user.
usage: python tools/fetch_sticker.py candidates.json <number> <name> --project <project folder> --approved-by-user "yes, <date or words of the user>"
Saves to <project>/stickers/raw/<name>.<ext> and appends: file, page URL, licence, creator, date, approval to <project>/SOURCES.tsv.
Never run it on your own initiative: the user must have seen the list with links and licences and said yes (MISTAKES #22)."""
import datetime, json, shutil, sys, urllib.request
from pathlib import Path

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

def main():
    if len(sys.argv) < 4 or sys.argv[1] in ('-h', '--help'): print(__doc__); sys.exit(0 if len(sys.argv) > 1 and sys.argv[1] in ('-h', '--help') else 1)
    if not arg('--approved-by-user'): print('Refusing to download: the user has not approved this picture. Show the candidate list with links and licences, get a yes, then pass --approved-by-user "<their words>".'); sys.exit(2)
    project = Path(arg('--project', '.')); cand = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))['candidates']; c = cand[int(sys.argv[2]) - 1]; name = sys.argv[3]
    raw = project / 'stickers' / 'raw'; raw.mkdir(parents=True, exist_ok=True)
    ext = Path(c['url'].split('?')[0]).suffix.lower() or '.jpg'
    if ext not in ('.jpg', '.jpeg', '.png'): ext = '.jpg'
    dest = raw / f'{name}{ext}'
    if dest.exists(): print(f'{dest} already exists: choose another name (every file stays, MISTAKES #22)'); sys.exit(2)
    req = urllib.request.Request(c['url'], headers={'User-Agent': 'paper-collage-reel-skill/1.0'})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest, 'wb') as f: shutil.copyfileobj(r, f)
    from PIL import Image
    try: Image.open(dest).verify()
    except Exception: dest.unlink(); print('the downloaded file is not a valid image; deleted'); sys.exit(3)
    log = project / 'SOURCES.tsv'
    if not log.exists(): log.write_text('file\tsource_url\tlicense\tcreator\tdownloaded_on\tapproved_by_user\n', encoding='utf-8')
    with open(log, 'a', encoding='utf-8') as f: f.write(f"{dest.relative_to(project)}\t{c['page']}\t{c['license']}\t{c['creator']}\t{datetime.date.today()}\t{arg('--approved-by-user')}\n")
    print(f"saved {dest} ({dest.stat().st_size / 1e6:.2f} MB), logged in {log}")
    if c['license'] == 'by': print('Licence CC BY: the credit must stay with the video: ' + (c.get('attribution') or c['creator']))

if __name__ == '__main__': main()
