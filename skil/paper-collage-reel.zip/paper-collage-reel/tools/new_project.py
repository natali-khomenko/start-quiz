"""Create a project folder with the audit-trail structure, a brand file and a brief to fill in.
usage: python tools/new_project.py <folder> [--preset default|natali]
Creates: brief.yml, brand.yml, voice/, refs/ (style references brought by the user), photos/ (hero photos), stickers/ (objects the story needs: raw/ = downloaded originals), cutouts/, scenes/, renders/, critic/, SOURCES.tsv"""
import shutil, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    if len(sys.argv) < 2: print(__doc__); sys.exit(1)
    if sys.argv[1].startswith('-'): print(__doc__); sys.exit(0 if sys.argv[1] in ('-h', '--help') else 1)
    p = Path(sys.argv[1])
    if p.exists() and any(p.iterdir()): print(f'{p} already exists and is not empty: choose a new folder'); sys.exit(2)
    for d in ('voice', 'refs', 'photos', 'stickers', 'cutouts', 'scenes', 'renders', 'critic'): (p / d).mkdir(parents=True, exist_ok=True)
    preset = arg('--preset', 'default'); src = ROOT / 'presets' / preset / 'brand.yml'
    if not src.exists(): print(f'unknown preset {preset}'); sys.exit(2)
    shutil.copy(src, p / 'brand.yml'); shutil.copy(ROOT / 'templates' / 'brief.yml', p / 'brief.yml')
    (p / 'script.md').write_text('# Script (approved word for word by the user)\n\nWrite the final text here only after the user said yes. Under it, one line per scene: what the voice says -> what the viewer sees.\n', encoding='utf-8')
    (p / 'SOURCES.tsv').write_text('file\tsource_url\tlicense\tcreator\tdownloaded_on\tapproved_by_user\n', encoding='utf-8')
    print(f'project created: {p}\nPut your spec in {p}/scenes/ and start it with:  brand: ../brand.yml   (paths in a spec are relative to the spec file, e.g. ../cutouts/hero-center.png)\nNext: fill brief.yml with the user, put the voice recording in voice/, then run tools/transcribe.py')

if __name__ == '__main__': main()
