"""Cut-out CLI.
  object  <photo> <out.png>                       cut one object (model downloads once, ~170 MB)
  grid    <photo> <out.png>                       photo with a coordinate grid to read the head landmarks
  head    <photo> <out.png> [--cx N --top N --chin N | --auto] [--hair auto|dark|person]  (writes <out>.json with the face axis for the scene engine)
  mirror  <in.png> <out.png>                      horizontal mirror (use for the other gaze direction)
  gallery <out.png> <cutout.png> [...]            contact sheet on light / dark / pink backgrounds (approval gate 2)"""
import sys, json
from pathlib import Path
from PIL import Image
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine import cutout

def arg(name, default=None):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else default

def main():
    if '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0)
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    cmd = sys.argv[1]
    if cmd == 'object': cutout.cut_object(Image.open(sys.argv[2])).save(sys.argv[3]); print('saved', sys.argv[3])
    elif cmd == 'grid': print(cutout.grid_preview(Image.open(sys.argv[2]), sys.argv[3]))
    elif cmd == 'mirror': cutout.mirror(Image.open(sys.argv[2]).convert('RGBA')).save(sys.argv[3]); print('saved', sys.argv[3])
    elif cmd == 'gallery': print(cutout.gallery(sys.argv[3:], sys.argv[2]))
    elif cmd == 'head':
        img = Image.open(sys.argv[2])
        if '--auto' in sys.argv:
            lm = cutout.auto_landmarks(img)
            if not lm: print('No face found. Use `grid`, read cx/top/chin by eye and pass --cx --top --chin.'); sys.exit(2)
        else: lm = {'cx': float(arg('--cx')), 'top_y': float(arg('--top')), 'chin_y': float(arg('--chin'))}
        print('landmarks', {k: round(v) for k, v in lm.items()})
        res, meta = cutout.cut_head(img, lm, hair=arg('--hair', 'auto'), return_meta=True); out = Path(sys.argv[3]); res.save(out)
        out.with_suffix('.json').write_text(json.dumps(meta)); print('saved', out, meta)
    else: print(__doc__); sys.exit(1)
if __name__ == '__main__': main()
