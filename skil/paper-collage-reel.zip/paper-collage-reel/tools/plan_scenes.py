"""Draft the scene plan from the transcript (approval gate 1). Cuts fall in the silences between phrases (at least 0.12 s), never inside a word, and sit on the 12 fps grid.
It is a DRAFT built from the transcript's word times, which can be 0.1-0.3 s off: the user approves it and the render gate re-checks every cut against the words.
usage: python tools/plan_scenes.py words.json plan.yml [--min 1.6] [--max 4.5]
Writes plan.yml (a spec skeleton: scene id, start, end, empty elements, the spoken text as a comment) and prints a table to show the user."""
import json, math, sys
from pathlib import Path
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
FPS = 12; MIN_GAP = 0.12        # a cut needs a silence of at least 0.12 s: the wipe is 0.18 s, centred on the cut

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d
def snap(t): return round(round(t * FPS) / FPS, 4)
END_MARKS = tuple('.!?…')

def phrases(words, gap=0.25):
    words = [w for w in words if w['word'].strip()]
    out, cur = [], []
    for i, w in enumerate(words):
        cur.append(w); nxt = words[i + 1] if i + 1 < len(words) else None
        g = (nxt['start'] - w['end']) if nxt else 9
        if nxt is None or g >= gap or (w['word'].rstrip('"»)\'”').endswith(END_MARKS) and g >= MIN_GAP): out.append(cur); cur = []
    return out

def split_long(p, mx, tiny=0.04):
    """A phrase spoken without a real pause but longer than `mx`: cut it at the best small gap (a comma gap if possible), never inside a word."""
    if p[-1]['end'] - p[0]['start'] <= mx: return [p]
    best, bi = None, None
    for i in range(1, len(p)):
        gap = p[i]['start'] - p[i - 1]['end']; left = p[i - 1]['end'] - p[0]['start']
        if gap >= tiny and 1.0 <= left <= mx:
            score = gap + (0.05 if p[i - 1]['word'][-1:] in ',;:' else 0) + 0.05 * (left / mx)
            if best is None or score > best: best, bi = score, i
    return [p] if bi is None else [p[:bi]] + split_long(p[bi:], mx, tiny)

def plan(words, mn=1.6, mx=4.5, total=None):
    ph = [q for p in phrases(words) for q in split_long(p, mx)]; scenes = []; cur = []
    for p in ph:
        t0 = cur[0][0]['start'] if cur else p[0]['start']
        if cur and (p[-1]['end'] - t0 > mx or (cur[-1][-1]['end'] - t0 >= mn and p[-1]['end'] - t0 > mn + 0.8)): scenes.append(cur); cur = []
        cur.append(p)
    if cur: scenes.append(cur)
    while len(scenes) > 1 and scenes[-1][-1][-1]['end'] - scenes[-1][0][0]['start'] < 1.2: scenes[-2] += scenes.pop()      # no tiny tail scene (it could never hold the picture)
    res = []
    for i, sc in enumerate(scenes):
        a = sc[0][0]['start']; b = sc[-1][-1]['end']
        nxt = scenes[i + 1][0][0]['start'] if i + 1 < len(scenes) else (total or b + 0.4)
        start = 0.0 if i == 0 else res[-1]['end']; end = snap((b + nxt) / 2) if i + 1 < len(scenes) else math.ceil(max(b + 0.4, total or 0) * FPS) / FPS   # cut in the middle of the silence, on the 12 fps grid
        prev_end = scenes[i - 1][-1][-1]['end'] if i else 0.0; gap_before = sc[0][0]['start'] - prev_end
        res.append({'id': f's{i + 1}', 'start': start, 'end': round(end, 4), 'text': ' '.join(w['word'] for p in sc for w in p), 'cut': bool(i and gap_before < MIN_GAP)})   # no real silence there: a wipe would run over a word, so use a hard cut
    return res

if __name__ == '__main__':
    if len(sys.argv) < 3 or '-h' in sys.argv or '--help' in sys.argv: print(__doc__); sys.exit(0 if ('-h' in sys.argv or '--help' in sys.argv) else 1)
    d = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    if not [w for w in d['words'] if w['word'].strip()]: print('The transcript has no words: check the recording and the language, then transcribe again.'); sys.exit(2)
    sc = plan(d['words'], float(arg('--min', 1.6)), float(arg('--max', 4.5)), d.get('duration'))
    lines = ['# Scene plan draft: fill `elements` for each scene. Times in seconds; cuts sit inside silences.', 'brand: ' + str((Path(__file__).resolve().parent.parent / 'presets' / 'default' / 'brand.yml')).replace(chr(92), '/'), 'scenes:']
    for s in sc: lines += [f"  # {s['text']}", f"  - id: {s['id']}", f"    start: {s['start']}", f"    end: {s['end']}"] + (["    transition: cut   # the speech is continuous here (no silence of 0.12 s): a wipe would cover a word"] if s['cut'] else []) + ["    elements: []"]
    Path(sys.argv[2]).write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(f"{'scene':<6}{'start':>7}{'end':>7}{'len':>6}  text")
    for s in sc: print(f"{s['id']:<6}{s['start']:>7.2f}{s['end']:>7.2f}{s['end'] - s['start']:>6.2f}  {s['text']}" + ('   [hard cut]' if s['cut'] else ''))
