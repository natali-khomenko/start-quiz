"""Find free-licence pictures for the stickers the script needs. Searches only (nothing is downloaded): shows candidates with licence, size and the page to check.
usage: python tools/find_stickers.py "tennis ball" [--license cc0,pdm] [--limit 8] [--out candidates.json] [--attribution]
Default licences: cc0 and pdm (public domain: no attribution needed). --attribution also allows cc-by (the credit is then written to SOURCES.tsv and must stay with the video).
Source: Openverse (openverse.org), which indexes Flickr, Wikimedia Commons and others. Show the list to the user; download only after the user says yes (tools/fetch_sticker.py)."""
import json, sys, urllib.parse, urllib.request
from pathlib import Path

def arg(n, d=None):
    i = sys.argv.index(n) + 1 if n in sys.argv else None
    return sys.argv[i] if i is not None and i < len(sys.argv) else d

def search(query, licenses='cc0,pdm', limit=8):
    url = 'https://api.openverse.org/v1/images/?' + urllib.parse.urlencode({'q': query, 'license': licenses, 'page_size': limit, 'mature': 'false', 'extension': 'jpg,png'})
    req = urllib.request.Request(url, headers={'User-Agent': 'paper-collage-reel-skill/1.0'})
    with urllib.request.urlopen(req, timeout=30) as r: data = json.loads(r.read().decode('utf-8'))
    out = []
    for it in data.get('results', []):
        out.append({'title': it.get('title') or '', 'creator': it.get('creator') or '', 'license': it.get('license'), 'license_url': it.get('license_url'), 'width': it.get('width'), 'height': it.get('height'),
                    'url': it.get('url'), 'page': it.get('foreign_landing_url'), 'source': it.get('source'), 'attribution': it.get('attribution') or ''})
    return out

def main():
    if len(sys.argv) < 2 or sys.argv[1] in ('-h', '--help') or sys.argv[1].startswith('-'): print(__doc__); sys.exit(0 if '--help' in sys.argv or '-h' in sys.argv else 1)
    lic = 'cc0,pdm,by' if '--attribution' in sys.argv else arg('--license', 'cc0,pdm')
    try: res = search(sys.argv[1], lic, int(arg('--limit', 8)))
    except Exception as e: print(f'search failed ({type(e).__name__}: {e}). Check the internet connection, or ask the user to supply the picture.'); sys.exit(3)
    if not res: print('no candidates: try other words (a plain object name in English works best) or ask the user for a picture'); sys.exit(4)
    if arg('--out'): Path(arg('--out')).write_text(json.dumps({'query': sys.argv[1], 'candidates': res}, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f'{len(res)} candidates for "{sys.argv[1]}" (licences: {lic}); check the picture on its page before choosing')
    for i, c in enumerate(res, 1): print(f"{i:>2}. {c['title'][:60]:<60} | {c['license']:<4} | {c['width'] or '?'}x{c['height'] or '?'} | {c['creator'][:24]:<24} | {c['page']}")

if __name__ == '__main__': main()
