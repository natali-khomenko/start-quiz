# MISTAKES — read this before ANY work with this skill

These rules come from real mistakes made while building the first paper-collage reel. Each one cost the author hours. Follow them as hard rules.

**Enforced in code** (the renderer refuses to render while one is violated; skip codes in brackets; the user may agree to skip one check for one scene: `--skip code:scene-id`, and every skip is logged next to the mp4):
#3 and #4 captions timed to words and reading speed (`caption-early`, `caption-word`, `reading-speed`, needs `word:` on the caption and `--words`), #2 and #7 a cut must not fall on a spoken word (`wipe-word`; a continuous-speech cut needs `transition: cut`), #5 arrival in the first half and hold of 0.8 s (`arrival`, `hold`, `exit-late`), #6 at most 6 elements and no overlaps (`count`, `overlap`), #10 head touching the body in a group (`head-gap`), #11 a pose used once (error when the spec is loaded, no skip code), #13 edge margin (`margin`), #15 missing glyph (error when the spec is loaded, no skip code), caption zone (`caption-zone`), contiguous scenes starting at 0 (`timeline`), voice never rescaled or truncated (mixer).

**Not enforceable by a measurement, so they are on you:** #1 (do not process the voice: the code does not, but never add a step that does), #8 repeated hero objects across scenes, #9 real cut-outs only, #12 hair edges (the user approves the gallery), #14 tape and ribbon placement, #16 to #22 process rules, 40 px spacing between captions and other labels.

## Voice and timing
1. **Never process or alter the user's voice** (no EQ, compressor, speed, pitch, denoise). Cutting out silence or a failed take is allowed. **Never insert artificial pauses**: a pause dropped into a "quiet" spot can land inside a word ("під-|писок") and also sounds unnatural. The picture follows the voice, never the other way round.
2. Scene boundaries come from **word timestamps** (transcription), at phrase ends, never mid-phrase or mid-word.
3. Captions appear **when the word is spoken**, not before. Never show a claim the voice has not made yet (e.g. a "free" sticker before the word "free").
4. Captions: at most 3 words per second of reading, inside the safe zone, at least 40 px away from other labels.

## Pace (the biggest complaint: "too fast, a pile of everything")
5. In every scene the key action finishes in the **first half** of the scene and the finished picture stays still for **at least 0.8 s**. Look at the scene's first 0.3 s and last 0.3 s: nothing may still be arriving when the next scene wipes in.
6. At most **6 elements per scene**. Group by meaning (clothes with clothes), never a pile.
7. Transitions are short (0.18 s or less), with no blank frames, and never cut a spoken word.
8. Do not repeat the same hero object in several scenes (the same folder twice looked like a mistake).

## Hero and cut-outs
9. **Real photo cut-outs only, collected by the user for THIS story.** Drawn or vector clothes and objects were rejected ("terrible"). The skill ships no premade stickers and Claude does not download pictures on its own: it works out from the script which objects are needed, tells the user what to search for and where (`tools/sticker_links.py`), and cuts out the pictures the user saves in `stickers/raw/`. Paper furniture (torn sheet, label, caption, tape, speech bubble) and the beating heart are drawn by the engine and are fine; the drawn pictorial pieces (plate, fork, knife, folder, birds, note, star, burst) are a last-resort fallback that needs the user's agreement.
10. Hero head: **no neck, no glasses unless asked, ONE head**. It must sit **on the neck of the body, not on the shoulder**: measure the neck centre from the body image itself (a wrong number in a data file put a head 170 px off, and nobody noticed for hours). Head and body **appear together without a scale-pop**, otherwise one grows under the other and looks detached. After placing, look at the picture and check the chin-to-collar gap (10 px or less).
11. Expressions are scripted, not random: each pose is held, the last one stays (no looping). Left/right gaze comes from **mirroring** the side-glance pose. No open mouth unless the user asked for it.
12. Hair edges: cut with a **colour mask** (skin/hair colours) combined with the model output, then check the edge on a contrasting background. Remove leftover background (a couch or pillow behind the hair is common). The user approves the cut-out gallery before any scene uses it.
13. Nothing is cropped by the frame edge: keep a margin of at least 60 px (rays and shadows may touch the edge on purpose, objects may not).

## Paper details
14. Tape: **one strip per print**, on a corner or the top edge, never across the middle of a photo. A ribbon goes **below** a label, never over its text; a bow has loops and tails, not a flat bar.
15. Check that the font really has every glyph you use (the hryvnia sign was missing in one font and rendered as a box). `Brand.has_glyphs()` does this.

## Process
0. **Script and look come from the user, before any visual.** Never invent the story, names, claims or brand colours (a demo built on an invented story and a silently chosen pink palette was rejected). Every scene traces back to one sentence of the approved script.
16. **Show the scene layout with timings and get a "yes" before rendering.** Do not change things the user did not ask to change; discuss first.
17. **Judge motion, not the end state.** Review strips at 3-5 frames per second including the first and last 0.3 s of each scene. End-state stills hid every pacing bug.
18. **Run a separate critic agent before showing anything.** Give it the exact "wanted / rejected" lists (an earlier critic received them swapped and produced wrong findings) and let it watch the video, not stills. Fix its findings, at most two rounds, then tell the user what it found and fixed. If the critic is unavailable (account limit), say so; never deliver silently.
19. Never say "done" without opening the result. Verify numbers by looking at the image (anchors, positions, durations).
20. The user's dictated text contains mishearings (brand and product names, "Buddy" for "Body"). Normalise spelling with the user once, then keep it.
21. No competitor or service names and no logos on screen unless the user supplied them and decided to show them. Do not bundle other people's logos.
22. Keep every render version (`-v1`, `-v2`) and every log: the audit trail matters. Write sources of downloaded images to `SOURCES.tsv`; Claude downloads only if the user asked it to and approved the file (`tools/fetch_sticker.py` refuses without that).
