"""Stage-2 checks: scene spec loads, elements render, hero poses switch, heart beats, birds leave the frame, head cut-out works.
usage: python tests/test_stage2.py [--with-models]   (--with-models also cuts a head and an object; downloads models once)"""
import sys
from pathlib import Path
import numpy as np
from PIL import Image
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine.scene import Spec
ok = True
def check(name, cond, info=''):
    global ok; print(('  OK   ' if cond else '  FAIL ') + name + ('' if cond else f'  -> {info}')); ok = ok and bool(cond)
def diff(a, b): return float(np.abs(np.array(a.convert('RGB')).astype(float) - np.array(b.convert('RGB')).astype(float)).mean())

spec = Spec(ROOT / 'tests' / 'demo' / 'demo.yml'); hook = spec.scene('hook'); birds = spec.scene('birds')
check('spec loads two scenes', len(spec.scenes) == 2)
f0, f1, f2 = hook.frame(0.05), hook.frame(0.2), hook.frame(2.3)
check('elements appear over time', diff(f0, f1) > 1 and diff(f1, f2) > 1)
check('hero pose switches (mirror) between 0.4 s and 1.0 s', diff(hook.frame(0.45), hook.frame(1.05)) > 0.5)
check('heart beats (frames differ inside the beat)', diff(hook.frame(2.0 + 0.0), hook.frame(2.0 + 1 / 12 * 2)) > 0.05)
a, b = birds.frame(birds.start + 0.2), birds.frame(birds.start + 1.0); c = birds.frame(birds.start + 2.35)
check('birds appear', diff(a, b) > 1)
check('birds are gone from the frame at the end (only background, folder and caption remain)', diff(c, birds.frame(birds.start + 2.4)) < 3 and np.array(c.convert('RGB'))[:700].std() < 60)
check('every frame is 1080x1920', hook.frame(1.0).size == (1080, 1920))
# --- rule checks and safety nets
check('demo spec passes its own rule checks', not spec.check(), spec.check())
import yaml, tempfile, subprocess, os
def spec_from(text):
    d = Path(tempfile.mkdtemp()); (d / 's.yml').write_text(text, encoding='utf-8'); return d / 's.yml'
base = "brand: %s\nscenes:\n  - {id: s, start: 0, end: 2, elements: [%%s]}\n" % (ROOT / 'presets' / 'default' / 'brand.yml')
many = ', '.join("{type: star, size: 100, x: %d, y: 600, at: 0.1}" % (100 + 140 * i) for i in range(7))
check('more than 6 elements is reported', any('more than 6' in v for v in Spec(spec_from(base % many)).check()))
check('element near the edge is reported', any('frame edge' in v for v in Spec(spec_from(base % "{type: star, size: 100, x: 10, y: 600, at: 0.1}")).check()))
check('late arrival / short hold is reported', any('holds only' in v for v in Spec(spec_from(base % "{type: star, size: 100, x: 500, y: 600, at: 1.7}")).check()))
try: Spec(spec_from(base % "{type: caption, text: 'hello', accent: 'XYZ', at: 0.1}")); check('caption accent missing from text raises', False)
except ValueError: check('caption accent missing from text raises', True)
try: Spec(spec_from(base % "{type: label, text: 'a ₴ b', font: display, at: 0.1}")); check('missing glyph raises', False)
except ValueError: check('missing glyph raises', True)
two = "heroes: {h: {a: %s}}\n" % (ROOT / 'tests' / 'demo' / 'hero-center.png')
try: Spec(spec_from((two + base) % "{type: hero, hero: h, bottom_center: [540, 900], at: 0.1, poses: [{pose: a, at: 0.1}, {pose: a, at: 0.6}]}")); check('repeated pose raises', False)
except ValueError: check('repeated pose raises', True)
code = "import sys; sys.path.insert(0, %r); from engine.scene import Spec; import hashlib; s = Spec(%r).scene('hook'); print(hashlib.md5(s.frame(1.0).tobytes()).hexdigest())" % (str(ROOT), str(ROOT / 'tests' / 'demo' / 'demo.yml'))
h = [subprocess.run([sys.executable, '-c', code], capture_output=True, text=True, env={**os.environ, 'PYTHONHASHSEED': sd}).stdout.strip()[-32:] for sd in ('1', '2')]
check('rendering is deterministic across processes (jitter does not depend on hash())', h[0] == h[1] and len(h[0]) == 32, h)
if '--with-models' in sys.argv:
    from skimage import data
    from engine import cutout
    img = Image.fromarray(data.astronaut()); lm = cutout.auto_landmarks(img); check('face detector finds the portrait', lm is not None)
    head = cutout.cut_head(img, lm, hair='person'); check('head cut-out has a transparent background and a rounded chin', head.mode == 'RGBA' and np.array(head.getchannel('A'))[-1].max() < 255 * 0.8 + 1 and head.height > 1000)
    obj = cutout.cut_object(Image.fromarray(data.chelsea())); check('object cut-out returns RGBA', obj.mode == 'RGBA')
print('\nSTAGE 2 OK' if ok else '\nSTAGE 2 FAILED'); sys.exit(0 if ok else 1)
