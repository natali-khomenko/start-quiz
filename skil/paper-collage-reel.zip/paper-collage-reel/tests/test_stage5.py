"""Stage-5 checks: the sticker tools never download without approval and log what they fetch (offline test with a local file:// source).
usage: python tests/test_stage5.py [--online]   (--online also runs one real Openverse search)"""
import json, subprocess, sys, tempfile
from pathlib import Path
from PIL import Image
ROOT = Path(__file__).resolve().parent.parent; py = sys.executable; ok = True
def check(name, cond, info=''):
    global ok; print(('  OK   ' if cond else '  FAIL ') + name + ('' if cond else f'  -> {info}')); ok = ok and bool(cond)
tmp = Path(tempfile.mkdtemp()); proj = tmp / 'proj'; r = subprocess.run([py, str(ROOT / 'tools' / 'new_project.py'), str(proj)], capture_output=True, text=True)
check('project has a stickers folder', (proj / 'stickers').is_dir())
img = tmp / 'ball.png'; Image.new('RGB', (64, 64), (200, 220, 40)).save(img)
cand = tmp / 'c.json'; cand.write_text(json.dumps({'query': 'ball', 'candidates': [{'title': 'ball', 'creator': 'someone', 'license': 'cc0', 'url': img.as_uri(), 'page': 'https://example.org/ball', 'attribution': ''}]}), encoding='utf-8')
r1 = subprocess.run([py, str(ROOT / 'tools' / 'fetch_sticker.py'), str(cand), '1', 'ball', '--project', str(proj)], capture_output=True, text=True)
check('fetch refuses without the approval flag and downloads nothing', r1.returncode == 2 and not (proj / 'stickers' / 'raw').exists() or (r1.returncode == 2 and not list((proj / 'stickers' / 'raw').glob('*'))), r1.stdout)
r2 = subprocess.run([py, str(ROOT / 'tools' / 'fetch_sticker.py'), str(cand), '1', 'ball', '--project', str(proj), '--approved-by-user', 'yes, test'], capture_output=True, text=True)
log = (proj / 'SOURCES.tsv').read_text(encoding='utf-8')
check('an approved fetch saves the file and logs source, licence, creator and approval', r2.returncode == 0 and (proj / 'stickers' / 'raw' / 'ball.png').exists() and 'example.org/ball' in log and 'cc0' in log and 'yes, test' in log, r2.stdout + r2.stderr)
r3 = subprocess.run([py, str(ROOT / 'tools' / 'fetch_sticker.py'), str(cand), '1', 'ball', '--project', str(proj), '--approved-by-user', 'yes'], capture_output=True, text=True)
check('an existing file is never overwritten', r3.returncode == 2)
r6 = subprocess.run([py, str(ROOT / 'tools' / 'sticker_links.py'), 'tennis ball'], capture_output=True, text=True); check('sticker_links prints search links for several sites', r6.returncode == 0 and 'pexels.com/search/tennis%20ball' in r6.stdout and 'pixabay.com' in r6.stdout and 'unsplash.com' in r6.stdout, r6.stdout[:200])
r4 = subprocess.run([py, str(ROOT / 'tools' / 'find_stickers.py'), '--help'], capture_output=True, text=True); check('find_stickers prints its usage', 'Openverse' in r4.stdout)
if '--online' in sys.argv:
    r5 = subprocess.run([py, str(ROOT / 'tools' / 'find_stickers.py'), 'tennis ball', '--limit', '3', '--out', str(tmp / 'o.json')], capture_output=True, text=True)
    check('a real search returns candidates with licences and page links', r5.returncode == 0 and json.loads((tmp / 'o.json').read_text())['candidates'][0]['page'], r5.stdout + r5.stderr)
print('\nSTAGE 5 TOOLS OK' if ok else '\nSTAGE 5 TOOLS FAILED'); sys.exit(0 if ok else 1)
