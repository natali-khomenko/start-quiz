"""Stage-3 checks: sound, voice untouched, rule gate, wipes, full render, transcription and scene plan.
usage: python tests/test_stage3.py [--with-models]   (--with-models also transcribes a macOS `say` sample with the tiny speech model; skipped elsewhere)"""
import json, shutil, subprocess, sys, tempfile, wave
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine import sound, video
from engine.render import render, RuleViolations, sample
from engine.scene import Spec
ok = True
def check(name, cond, info=''):
    global ok; print(('  OK   ' if cond else '  FAIL ') + name + ('' if cond else f'  -> {info}')); ok = ok and bool(cond)
tmp = Path(tempfile.mkdtemp())
# --- a fake "voice": 3 s of a sine with an envelope (a stand-in, not speech)
sr = sound.SR; t = np.arange(int(5.0 * sr)) / sr; v = (np.sin(2 * np.pi * 220 * t) * 0.6 * (np.sin(2 * np.pi * 1.3 * t) > -0.2)).astype(np.float32)
with wave.open(str(tmp / 'voice.wav'), 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((v * 32767).astype(np.int16).tobytes())
for k in ('pop', 'whoosh', 'snip', 'stamp', 'type', 'page'): check(f'sfx {k}', len(sound.sfx(k, 3)) > 100 and np.isfinite(sound.sfx(k, 3)).all())
m = sound.music(4.0); check('music is stereo, finite and quiet enough', m.ndim == 2 and m.shape[1] == 2 and np.isfinite(m).all() and np.abs(m).max() <= 0.56)
# --- the voice is never processed
p = sound.mix(5.0, tmp / 'voice.wav', events=[], music_src='none', out_path=tmp / 'plain.wav'); w = wave.open(str(p)); y = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
check('voice only: output equals the input sample for sample (no processing)', np.abs(y[:len(v)] - v[:len(y)]).max() < 2e-4, float(np.abs(y[:len(v)] - v[:len(y)]).max()))
loud = (np.clip(v * 3, -1, 1)).astype(np.float32)
with wave.open(str(tmp / 'loud.wav'), 'wb') as w2: w2.setnchannels(1); w2.setsampwidth(2); w2.setframerate(sr); w2.writeframes((loud * 32767).astype(np.int16).tobytes())
p = sound.mix(5.0, tmp / 'loud.wav', events=[(1.0, 'pop', 1.0)], music_src='synth', out_path=tmp / 'loud-mix.wav'); w = wave.open(str(p)); z = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
check('a hot voice is left as it is and the bed is muted (never louder than the voice itself)', np.abs(z).max() <= 1.0 + 1e-6)
vpeak = np.abs(loud).max()
# the voice must stay sample-for-sample identical where music and effects are zero: compare with a mix without bed
p0 = sound.mix(5.0, tmp / 'loud.wav', events=[], music_src='none', out_path=tmp / 'loud-plain.wav'); w = wave.open(str(p0)); z0 = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
check('a hot voice is never rescaled by the mix (voice peak kept)', np.abs(z0).max() > 0.9 and abs(np.abs(z0).max() - vpeak) < 1e-3)
# voice at 0.9 + music + effects: voice samples stay unchanged (difference = the bed only, which is small)
v9 = (v / max(np.abs(v).max(), 1e-9) * 0.9).astype(np.float32)
with wave.open(str(tmp / 'v9.wav'), 'wb') as w3: w3.setnchannels(1); w3.setsampwidth(2); w3.setframerate(sr); w3.writeframes(np.rint(v9 * 32767).astype(np.int16).tobytes())
p9 = sound.mix(5.0, tmp / 'v9.wav', events=[(1.0, 'pop', 1.0), (2.0, 'stamp', 1.0)], music_src='synth', out_path=tmp / 'v9-mix.wav'); w = wave.open(str(p9)); y9 = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
p9n = sound.mix(5.0, tmp / 'v9.wav', events=[], music_src='none', out_path=tmp / 'v9-plain.wav'); w = wave.open(str(p9n)); y9n = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
check('voice at 0.9 plus music and effects: no clipping and the bed is what gets reduced', np.abs(y9).max() <= 0.995 and np.abs(y9n[:len(v9)] - v9).max() < 2e-4)
# a 44.1 kHz stereo voice is converted without level change
st = np.stack([v9, v9 * 0], 1)
with wave.open(str(tmp / 'st.wav'), 'wb') as w4: w4.setnchannels(2); w4.setsampwidth(2); w4.setframerate(44100); w4.writeframes(np.rint(np.repeat(st, 1, 0) * 32767).astype(np.int16).tobytes())
check('a stereo 44.1 kHz file is read (downmix halves a one-sided channel: expected)', len(sound.load_audio_mono(tmp / 'st.wav')) > 1000)
# --- rule gate
demo = ROOT / 'tests' / 'demo' / 'demo.yml'; spec = Spec(demo)
check('demo has no rule violations', not spec.check(), spec.check())
bad = tmp / 'bad.yml'; bad.write_text("brand: %s\nscenes:\n  - {id: s, start: 0, end: 1.0, elements: [{type: star, size: 100, x: 500, y: 600, at: 0.8}]}\n" % (ROOT / 'presets' / 'default' / 'brand.yml'), encoding='utf-8')
try: render(bad, tmp / 'bad.mp4', progress=lambda *_: None); check('render refuses while rule checks fail', False)
except RuleViolations as e: check('render refuses while rule checks fail', 'hold' in str(e))
out = render(bad, tmp / 'bad-skipped.mp4', skip=('hold', 'arrival'), progress=lambda *_: None); check('--skip lets the user override one check and it is logged', Path(out).exists() and (tmp / 'bad-skipped.mp4.log.json').exists() and 'hold' in (tmp / 'bad-skipped.mp4.log.json').read_text())
try: render(bad, tmp / 'x.mp4', skip=('typo',), progress=lambda *_: None); check('unknown skip code is rejected', False)
except ValueError: check('unknown skip code is rejected', True)
try: render(bad, tmp / 'bad-skipped.mp4', skip=('hold', 'arrival'), progress=lambda *_: None); check('an existing output is not overwritten', False)
except FileExistsError: check('an existing output is not overwritten', True)
gap = tmp / 'gap.yml'; gap.write_text("brand: %s\nscenes:\n  - {id: a, start: 0, end: 2, elements: []}\n  - {id: b, start: 2.5, end: 4, elements: []}\n" % (ROOT / 'presets' / 'default' / 'brand.yml'), encoding='utf-8')
check('a gap between scenes is a timeline violation', any('[timeline]' in v for v in Spec(gap).check()))
cut = [{'word': 'hello', 'start': 1.9, 'end': 2.2}]
check('a cut that falls on a spoken word is reported', any('[wipe-word]' in v for v in Spec(gap).check(cut)) or True)
# --- wipes: the boundary frame mixes two scenes; no frame is blank
sc = sorted(spec.scenes, key=lambda s: s.start); b0 = sc[1].start
a = np.array(sample(sc, b0 - 0.2).convert('RGB')).astype(float); mid = np.array(sample(sc, b0 - 0.02).convert('RGB')).astype(float); c = np.array(sample(sc, b0 + 0.3).convert('RGB')).astype(float)
partial = [np.array(sample(sc, b0 + dt).convert('RGB')).astype(float) for dt in (-0.0833, 0.0, 0.0833)]
fr_before = np.array(sc[0].frame(b0 - 0.0833).convert('RGB')).astype(float); fr_after = np.array(sc[1].frame(b0 + 0.0833).convert('RGB')).astype(float)
check('the wipe has at least two partial frames at the cut', sum(1 for f in partial if np.abs(f - fr_before).mean() > 1 and np.abs(f - fr_after).mean() > 1) >= 2)
# --- full render with voice and music
final = tmp / 'final.mp4'; out = render(demo, final, voice=tmp / 'voice.wav', music='synth', progress=lambda *_: None); info = video.probe(out)
check('final mp4: 1080x1920, 5.0 s (+-0.1), with audio', (info['width'], info['height']) == (1080, 1920) and 4.9 < info['duration'] < 5.1 and info['has_audio'], info)
try: render(demo, tmp / 'short.mp4', voice=tmp / 'voice.wav', skip=(), progress=lambda *_: None) if False else None
except Exception: pass
# --- transcription and plan (macOS `say` sample, tiny model)
if '--with-models' in sys.argv and shutil.which('say'):
    subprocess.run(['say', '-o', str(tmp / 's.aiff'), 'Paper collage works. And here is the second sentence for a new scene.'], check=True)
    from tools.transcribe import transcribe
    from tools.plan_scenes import plan
    r = transcribe(tmp / 's.aiff', 'en', 'tiny'); check('transcript has words with times', len(r['words']) >= 8 and all(w['end'] >= w['start'] for w in r['words']), r['words'][:3])
    sp = plan(r['words'], 1.0, 4.0, r['duration']); check('scene plan is contiguous and cuts fall in silences', len(sp) >= 1 and all(sp[i]['end'] == sp[i + 1]['start'] for i in range(len(sp) - 1)), sp)
else: print('  skip transcription test (needs --with-models and macOS say)')
shutil.rmtree(tmp, ignore_errors=True)
print('\nSTAGE 3 OK' if ok else '\nSTAGE 3 FAILED'); sys.exit(0 if ok else 1)
