"""Stage-4 checks: project scaffold, critic pack, the spec reference example loads and its types exist in the engine.
usage: python tests/test_stage4.py"""
import re, shutil, subprocess, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent; sys.path.insert(0, str(ROOT))
from engine.scene import Spec
from engine.render import render
ok = True
def check(name, cond, info=''):
    global ok; print(('  OK   ' if cond else '  FAIL ') + name + ('' if cond else f'  -> {info}')); ok = ok and bool(cond)
tmp = Path(tempfile.mkdtemp()); py = sys.executable
r = subprocess.run([py, str(ROOT / 'tools' / 'new_project.py'), str(tmp / 'proj'), '--preset', 'natali'], capture_output=True, text=True)
check('new_project creates the structure', r.returncode == 0 and all((tmp / 'proj' / d).is_dir() for d in ('voice', 'refs', 'photos', 'cutouts', 'scenes', 'renders', 'critic')) and (tmp / 'proj' / 'brief.yml').exists() and (tmp / 'proj' / 'SOURCES.tsv').exists(), r.stdout + r.stderr)
r2 = subprocess.run([py, str(ROOT / 'tools' / 'new_project.py'), str(tmp / 'proj')], capture_output=True, text=True); check('new_project refuses a non-empty folder', r2.returncode == 2)
doc = (ROOT / 'docs' / 'SPEC-REFERENCE.md').read_text(encoding='utf-8'); block = re.search(r'```yaml\n(.*?)```', doc, re.S).group(1)
ex = ROOT / 'tests' / 'demo' / '_reference_example.yml'; ex.write_text(block, encoding='utf-8')
try:
    spec = Spec(ex); bad = spec.check(); check('the example in SPEC-REFERENCE.md loads and passes its own rule checks', not bad, bad)
    out = render(ex, tmp / 'ref.mp4', progress=lambda *_: None); check('the example renders', Path(out).exists())
finally: ex.unlink(missing_ok=True)
src = (ROOT / 'engine' / 'scene.py').read_text(encoding='utf-8')
types = re.findall(r'^\| `([a-z, `]+)` \|', doc.split('## Element types')[1].split('## Rules')[0], re.M)
names = [t.strip('` ') for row in types for t in row.split(',')]
check('every element type in the reference exists in the engine', all(f"'{n}'" in src for n in names if n), [n for n in names if f"'{n}'" not in src])
(tmp / 'wanted.txt').write_text('# the things the user likes\nbirds that fly out of the frame\nhead on the neck\n', encoding='utf-8'); (tmp / 'rejected.txt').write_text('open mouth\nlong pauses\n', encoding='utf-8')
r3 = subprocess.run([py, str(ROOT / 'tools' / 'critic_pack.py'), str(tmp / 'ref.mp4'), str(tmp / 'critic'), '--wanted', str(tmp / 'wanted.txt'), '--rejected', str(tmp / 'rejected.txt')], capture_output=True, text=True)
brief = (tmp / 'critic' / 'critic-brief.md').read_text(encoding='utf-8') if (tmp / 'critic' / 'critic-brief.md').exists() else ''
check('critic_pack writes frames, sheets and a brief with the wanted and rejected lists', r3.returncode == 0 and 'birds that fly out' in brief and 'open mouth' in brief and 'MISTAKES' in brief and len(list((tmp / 'critic' / 'frames').glob('*.jpg'))) >= 20 and (tmp / 'critic' / 'sheet-01.png').exists(), r3.stdout[-300:] + r3.stderr[-300:])
check('the brief lists WANTED before REJECTED and does not mix them', brief.index('WANTS') < brief.index('birds that fly out') < brief.index('REJECTED') < brief.index('open mouth'))
r4 = subprocess.run([py, str(ROOT / 'tools' / 'critic_pack.py'), str(tmp / 'ref.mp4'), str(tmp / 'c2')], capture_output=True, text=True); check('critic_pack refuses to run without both lists', r4.returncode != 0)
shutil.rmtree(tmp, ignore_errors=True)
print('\nSTAGE 4 OK' if ok else '\nSTAGE 4 FAILED'); sys.exit(0 if ok else 1)
