# One-time setup for Windows (PowerShell). Creates .venv in the skill folder, installs Python packages, checks ffmpeg.
# Not tested by the author on Windows: if something fails, paste the error into Claude Code and ask it to fix the script.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
Write-Host '== paper-collage-reel setup =='
$py = $null
foreach ($c in @('py -3.12', 'py -3.11', 'py -3.10', 'python')) {
  try { $v = Invoke-Expression "$c -c `"import sys; print(sys.version_info >= (3, 9))`"" 2>$null; if ($v -eq 'True') { $py = $c; break } } catch {}
}
if (-not $py) { Write-Host 'Python 3.9+ not found. Install it: winget install Python.Python.3.12'; exit 1 }
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Write-Host 'ffmpeg not found. Install it: winget install Gyan.FFmpeg  (then open a NEW terminal)'; exit 1 }
Invoke-Expression "$py -m venv .venv"
& .\.venv\Scripts\python.exe -m pip install --upgrade pip | Out-Null
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
Write-Host ''
Write-Host 'Packages installed. Next: .venv\Scripts\python.exe tools\doctor.py   then   .venv\Scripts\python.exe tools\smoke_test.py'
