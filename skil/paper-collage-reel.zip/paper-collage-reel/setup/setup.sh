#!/usr/bin/env bash
# One-time setup for macOS / Linux. Creates .venv in the skill folder, installs Python packages, checks ffmpeg.
set -e
cd "$(dirname "$0")/.."
echo "== paper-collage-reel setup =="
PY=""
for c in python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3.9+ not found."
  echo "  macOS:  brew install python@3.12   (install Homebrew first from https://brew.sh)"
  echo "  Ubuntu: sudo apt install python3 python3-venv"
  exit 1
fi
echo "Using $($PY --version)"
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg not found."
  echo "  macOS:  brew install ffmpeg"
  echo "  Ubuntu: sudo apt install ffmpeg"
  exit 1
fi
echo "ffmpeg: $(ffmpeg -version | head -1)"
"$PY" -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt
echo
echo "Packages installed. Next: .venv/bin/python tools/doctor.py   then   .venv/bin/python tools/smoke_test.py"
echo "Note: the first cut-out run downloads a ~170 MB background-removal model, the first transcription downloads a speech model. Both are one-time."
