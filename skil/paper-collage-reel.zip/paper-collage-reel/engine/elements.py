"""Procedural paper elements (no third-party pixels): backgrounds, plate, cutlery, folder, speech bubble, birds, burst, note, star.
Colours come from the brand (dark/light/soft/white/accent/muted) so nothing is hard-coded."""
import math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from . import paper

def gingham(size, c1, c2=(255, 255, 255), cell=64, seed=1):
    w, h = size; yy, xx = np.mgrid[:h, :w]; xb = (xx // cell) % 2 == 0; yb = (yy // cell) % 2 == 0
    base = np.array(c2, float)[None, None, :].repeat(h, 0).repeat(w, 1); col = np.array(c1, float)
    base[xb] = base[xb] * .45 + col * .55; base[yb] = base[yb] * .45 + col * .55
    weave = ((xx % 4 < 2) ^ (yy % 4 < 2)) * 7.0 + (np.random.default_rng(seed).random((h, w)) - .5) * 8
    return Image.fromarray((base + weave[..., None] - 4).clip(0, 255).astype('uint8')).convert('RGBA')

def sky(size, top=(238, 178, 198), bottom=(252, 232, 238), seed=3):
    w, h = size; g = np.linspace(0, 1, h)[:, None, None]
    arr = (np.array(top, float) * (1 - g) + np.array(bottom, float) * g).repeat(w, 1); im = Image.fromarray(arr.clip(0, 255).astype('uint8')).convert('RGBA')
    m = Image.new('L', size, 0); d = ImageDraw.Draw(m); r = random.Random(seed)
    for _ in range(14):
        cx, cy = r.randint(0, w), r.randint(0, h)
        for _ in range(6): x, y, rad = cx + r.randint(-140, 140), cy + r.randint(-40, 40), r.randint(60, 130); d.ellipse([x - rad, y - rad * .7, x + rad, y + rad * .7], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(22)).point(lambda v: int(v * .85)); im.paste(Image.new('RGBA', size, (255, 255, 255, 255)), (0, 0), m); return im

def kraft(size, seed=4):
    w, h = size; col = np.array((226, 186, 150), float); r = np.random.default_rng(seed)
    arr = col + (r.random((1, w, 1)) - .5) * 14 + (r.random((h, w, 1)) - .5) * 10
    return Image.fromarray(arr.clip(0, 255).astype('uint8')).convert('RGBA')

def metal(w, h, vertical=True):
    g = np.linspace(0, 1, w if not vertical else h); band = 150 + 80 * np.sin(g * math.pi * 3) ** 2
    arr = np.tile(band[:, None] if vertical else band[None, :], (1, w) if vertical else (h, 1))
    return Image.fromarray(np.stack([arr, arr, arr * 1.03], -1).clip(0, 255).astype('uint8')).convert('RGBA')

def plate(r=360, rim=(62, 39, 35)):
    n = r * 2 + 20; im = Image.new('RGBA', (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = n // 2
    d.ellipse([c - r, c - r, c + r, c + r], fill=(250, 248, 246, 255)); d.ellipse([c - r + 26, c - r + 26, c + r - 26, c + r - 26], outline=(226, 218, 212, 255), width=6)
    for i in range(36):
        a = 2 * math.pi * i / 36; x, y = c + (r - 14) * math.cos(a), c + (r - 14) * math.sin(a)
        d.arc([x - 20, y - 20, x + 20, y + 20], math.degrees(a) + 90, math.degrees(a) + 330, fill=tuple(rim) + (255,), width=4)
    sh = Image.new('L', (n, n), 0); ImageDraw.Draw(sh).ellipse([c - r + 40, c - r + 40, c + r - 40, c + r - 40], fill=40)
    im.alpha_composite(Image.merge('RGBA', [Image.new('L', (n, n), 120)] * 3 + [sh.filter(ImageFilter.GaussianBlur(30))])); return im

def fork(h=700):
    im = Image.new('RGBA', (140, h), (0, 0, 0, 0)); m = Image.new('L', im.size, 0); d = ImageDraw.Draw(m)
    for k in range(4): d.rounded_rectangle([18 + k * 30, 0, 38 + k * 30, int(h * .36)], 8, fill=255)
    d.rounded_rectangle([18, int(h * .22), 122, int(h * .36)], 30, fill=255); d.polygon([(52, int(h * .3)), (88, int(h * .3)), (96, h - 20), (44, h - 20)], fill=255); d.ellipse([40, h - 60, 100, h], fill=255)
    im.paste(metal(140, h), (0, 0), m); return im

def knife(h=720):
    im = Image.new('RGBA', (120, h), (0, 0, 0, 0)); m = Image.new('L', im.size, 0); d = ImageDraw.Draw(m)
    d.polygon([(30, 0), (110, 120), (104, int(h * .5)), (30, int(h * .5))], fill=255); d.rounded_rectangle([34, int(h * .48), 100, h - 10], 24, fill=255)
    im.paste(metal(120, h), (0, 0), m); return im

def folder(w, h, label, font, ink=(62, 39, 35)):
    im = Image.new('RGBA', (w, h + 40), (0, 0, 0, 0)); m = Image.new('L', im.size, 0); d = ImageDraw.Draw(m)
    d.polygon([(0, 40), (w * .34, 40), (w * .4, 0), (w * .98, 0), (w, 30), (w, h + 40), (0, h + 40)], fill=255)
    im.paste(kraft(im.size), (0, 0), m); d2 = ImageDraw.Draw(im)
    for k in range(3): d2.rectangle([30 + k * 8, 20 - k * 6, w - 40 - k * 6, 70], fill=(252, 250, 248, 255))
    d2.rectangle([0, 120, w, h + 40], fill=(0, 0, 0, 0)); front = kraft((w, h - 70), 9); fm = Image.new('L', front.size, 0); ImageDraw.Draw(fm).polygon([(0, 14), (w, 0), (w, h - 70), (0, h - 70)], fill=255)
    im.paste(front, (0, 110), fm); d2 = ImageDraw.Draw(im); d2.text((w // 2, 110 + (h - 70) // 2 + 20), label, font=font, fill=tuple(ink) + (255,), anchor='mm'); return im

def bubble(text, font, fill=(244, 201, 214), color=(62, 39, 35), tail='left'):
    d_ = ImageDraw.Draw(Image.new('RGB', (4, 4))); size = font.size; w = int(d_.textlength(text, font=font)) + 70; h = int(size * 2.2)
    im = Image.new('RGBA', (w, h + 30), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.rounded_rectangle([0, 0, w - 1, h], 34, fill=tuple(fill) + (255,))
    d.polygon([(40, h - 2), (90, h - 2), (30, h + 28)] if tail == 'left' else [(w - 90, h - 2), (w - 40, h - 2), (w - 30, h + 28)], fill=tuple(fill) + (255,))
    d.text((35, h // 2), text, font=font, fill=tuple(color) + (255,), anchor='lm'); return im

def burst(size=900, color=(255, 255, 255), pts=12):
    im = Image.new('RGBA', (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = size / 2; p = []
    for i in range(pts * 2): rr = c if i % 2 == 0 else c * .34; a = math.pi * i / pts - math.pi / 2; p.append((c + rr * math.cos(a), c + rr * math.sin(a)))
    d.polygon(p, fill=tuple(color) + (255,)); return im

def star(size, color, pts=8, inner=.4):
    im = Image.new('RGBA', (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im); c = size / 2; p = []
    for i in range(pts * 2): rr = c if i % 2 == 0 else c * inner; a = math.pi * i / pts - math.pi / 2; p.append((c + rr * math.cos(a), c + rr * math.sin(a)))
    d.polygon(p, fill=tuple(color) + (255,)); return im

def note(sz=110, color=(62, 39, 35)):
    im = Image.new('RGBA', (sz, sz * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(im); col = tuple(color) + (255,)
    d.ellipse([0, sz * 1.5, sz * .6, sz * 1.9], fill=col); d.rectangle([sz * .5, sz * .2, sz * .62, sz * 1.7], fill=col); d.polygon([(sz * .5, sz * .2), (sz * 1.0, sz * .5), (sz * 1.0, sz * .75), (sz * .5, sz * .45)], fill=col); return im

def cute_bird(body=(255, 255, 255), wing=(62, 39, 35), belly=(244, 201, 214), size=320, flap=0, flip=False, ink=(62, 39, 35)):
    """Cute drawn sparrow (supersampled): round body, big eye, tiny beak, rosy cheek, flapping wing (flap 0/1)."""
    k = 3; w, h = size * k, int(size * .86) * k; im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    def E(cx, cy, rx, ry, col): d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=tuple(col) + (255,))
    cx, cy = w * .48, h * .56
    d.polygon([(w * .13, h * .52), (w * .02, h * .36), (w * .10, h * .66)], fill=tuple(wing) + (255,)); d.polygon([(w * .13, h * .55), (w * .0, h * .55), (w * .12, h * .70)], fill=tuple(wing) + (255,))
    for lx in (.44, .56): d.line([(w * lx, h * .86), (w * lx, h * .98)], fill=tuple(ink) + (255,), width=int(w * .018)); d.line([(w * lx, h * .98), (w * (lx + .04), h * .98)], fill=tuple(ink) + (255,), width=int(w * .018))
    E(cx, cy, w * .36, h * .36, body); E(cx + w * .02, cy + h * .14, w * .24, h * .2, belly)
    wy = h * (.44 if flap == 0 else .24); wang = (-18 if flap == 0 else -50)
    wing_im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); wd = ImageDraw.Draw(wing_im); wd.ellipse([w * .20, wy, w * .62, wy + h * .26], fill=tuple(wing) + (255,)); wd.ellipse([w * .24, wy + h * .04, w * .52, wy + h * .14], fill=tuple(min(255, c + 45) for c in wing) + (255,))
    wing_im = wing_im.rotate(wang if flap else -8, center=(w * .50, h * .52), resample=Image.BICUBIC); im.alpha_composite(wing_im)
    d = ImageDraw.Draw(im); ex, ey = w * .66, h * .40
    E(ex, ey, w * .062, w * .062, (255, 255, 255)); E(ex + w * .006, ey + w * .004, w * .042, w * .042, ink); E(ex + w * .018, ey - w * .012, w * .014, w * .014, (255, 255, 255))
    E(w * .62, h * .55, w * .045, w * .03, (250, 150, 175)); d.polygon([(w * .80, h * .42), (w * .94, h * .485), (w * .80, h * .55)], fill=(232, 150, 70, 255))
    im = im.resize((size, int(size * .86)), Image.LANCZOS); return im.transpose(Image.FLIP_LEFT_RIGHT) if flip else im
