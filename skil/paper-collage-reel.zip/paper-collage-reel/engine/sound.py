"""Sound: minimal sound effects and a quiet original music bed, both synthesised (no licences). The VOICE IS NEVER PROCESSED:
it is only converted to 48 kHz mono and added at gain 1.0. Nothing is applied to it (no EQ, compressor, speed, pitch, denoise).
If the sum would clip, ONLY the music and the sound effects are scaled down (never the voice). If the voice alone is above 0.97 it is left as it is
and a warning is printed. The final mp4 stores the audio as AAC 192 kbit/s (that is a re-encode of the whole mix, the voice included)."""
import math, subprocess, shutil, wave
import numpy as np
SR = 48000

def _noise(n, seed=1): return np.random.default_rng(seed).standard_normal(n)
def _lp(x, a):
    y = np.zeros_like(x); s = 0.0
    for i in range(len(x)): s += a * (x[i] - s); y[i] = s
    return y
def _hp(x): return x - _lp(x, 0.08)

def sfx(kind, seed=1):
    r = np.random.default_rng(seed)
    if kind == 'pop':
        f0 = float(r.uniform(520, 940)); t = np.arange(int(.10 * SR)) / SR; x = np.sin(2 * np.pi * (f0 * np.exp(-t * 20) + 160) * t) * np.exp(-t * 42); x[:90] += _noise(90, seed) * .25 * np.linspace(1, 0, 90); return x * .9
    if kind == 'whoosh':
        n = int(.28 * SR); x = _noise(n, seed); env = np.sin(np.linspace(0, math.pi, n)); y = np.convolve(x, np.ones(40) / 40, 'same'); return y / (np.abs(y).max() + 1e-9) * env ** 2 * .7
    if kind == 'snip':
        n = int(.14 * SR); x = np.zeros(n)
        for st, g in ((0, 1.0), (int(.07 * SR), .8)):
            m = int(.045 * SR); t = np.arange(m) / SR; x[st:st + m] += (_hp(_noise(m, seed + st)) * np.exp(-t * 90) + np.sin(2 * np.pi * 4600 * t) * np.exp(-t * 130) * .5) * g
        return x * .8
    if kind == 'stamp':
        m = int(.22 * SR); t = np.arange(m) / SR; return (np.sin(2 * np.pi * 105 * t) * np.exp(-t * 20) + _hp(_noise(m, seed)) * np.exp(-t * 120) * .4) * .9
    if kind == 'type':
        m = int(.03 * SR); t = np.arange(m) / SR; return _hp(_noise(m, seed)) * np.exp(-t * 160) * 1.2 + np.sin(2 * np.pi * 1900 * t) * np.exp(-t * 200) * .3
    if kind == 'page':
        n = int(.40 * SR); x = _noise(n, seed); y = np.convolve(x, np.ones(12) / 12, 'same'); env = np.concatenate([np.linspace(0, 1, n // 5), np.linspace(1, .1, n - n // 5)]); return y / (np.abs(y).max() + 1e-9) * env * .5
    raise ValueError(f'unknown sfx kind {kind}')

def music(seconds, seed=7, bpm=100):
    """Soft original track (C-Am-F-G): marimba arpeggio, plucky bass, airy pad, shaker, tiny clicks, bell accents, light echo. Returns stereo float array."""
    BEAT = 60 / bpm; BAR = BEAT * 4; N = int(seconds * SR); L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(seed)
    def add(x, t, pan=.5, g=1.0):
        i = int(t * SR)
        if i >= N: return
        x = x[:N - i] * g; L[i:i + len(x)] += x * (1 - pan) * 1.4; R[i:i + len(x)] += x * pan * 1.4
    def tt(d): return np.arange(int(d * SR)) / SR
    def marimba(f, d=.6):
        t = tt(d); y = np.sin(2 * np.pi * f * t) * np.exp(-t * 7) + .35 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 18) + .1 * np.sin(2 * np.pi * 9.2 * f * t) * np.exp(-t * 40); y[:60] += rng.standard_normal(60) * .05 * np.linspace(1, 0, 60); return y
    def bass(f, d=.55): t = tt(d); return (np.sin(2 * np.pi * f * t) + .25 * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t * 4.5) * np.minimum(1, t * 120)
    def bell(f, d=1.2): t = tt(d); return (np.sin(2 * np.pi * f * t) + .4 * np.sin(2 * np.pi * 2.76 * f * t) * np.exp(-t * 3)) * np.exp(-t * 3.2)
    def pad(freqs, d): t = tt(d); y = sum(np.sin(2 * np.pi * f * t) + .3 * np.sin(2 * np.pi * f * 2.003 * t) for f in freqs); return y * np.minimum(1, t / .5) * np.minimum(1, (d - t) / .7) / len(freqs)
    def shaker(): m = int(.05 * SR); t = np.arange(m) / SR; n = rng.standard_normal(m); n = n - np.concatenate([[0], n[:-1]]); return n * np.exp(-t * 70)
    def tick(): m = int(.03 * SR); t = np.arange(m) / SR; return (np.sin(2 * np.pi * 1650 * t) + rng.standard_normal(m) * .3) * np.exp(-t * 120)
    C = [(130.81, [523.25, 659.25, 783.99], [130.81, 196.0, 261.63]), (110.0, [440.0, 523.25, 659.25], [110.0, 164.81, 220.0]), (87.31, [349.23, 440.0, 523.25], [87.31, 130.81, 174.61]), (98.0, [392.0, 493.88, 587.33], [98.0, 146.83, 196.0])]
    pats = [[0, 1, 2, 1, 0, 1, 2, 1], [0, 2, 1, 2, 0, 2, 1, 2], [2, 1, 0, 1, 2, 1, 0, 1]]
    for b in range(int(seconds / BAR) + 1):
        t0 = b * BAR; root, tones, padn = C[b % 4]; pat = pats[(b // 4) % 3]; add(pad(padn, BAR + .3), t0, .5, .22)
        for k in range(8):
            if b < 1 and k < 2: continue
            add(marimba(tones[pat[k]] * (2 if (b % 8 == 7 and k >= 6) else 1)), t0 + k * BEAT / 2, .35 + .3 * (k % 2), .55 if b >= 2 else .35)
        add(bass(root), t0, .5, .8); add(bass(root * 1.5 if b % 2 else root), t0 + 2 * BEAT, .5, .6)
        for k in range(8):
            if b >= 2 and k % 2 == 1: add(shaker(), t0 + k * BEAT / 2, .5 + .2 * (-1) ** k, .35)
        if b >= 3: add(tick(), t0 + BEAT, .65, .25); add(tick(), t0 + 3 * BEAT, .35, .25)
        if b % 2 == 0 and b >= 4: add(bell(tones[2] * 2), t0, .5, .22)
    dl = int(.3 * SR)
    def echo(x, d, g): y = x.copy(); y[d:] += x[:-d] * g; y[2 * d:] += x[:-2 * d] * g * .45; return y
    EL, ER = echo(L, dl, .28), echo(R, int(dl * 1.07), .22)
    fade = np.minimum(1, np.arange(N) / SR / 1.0) * np.minimum(1, (N - np.arange(N)) / SR / 2.2)
    out = np.stack([EL * fade, ER * fade], 1); return out / (np.abs(out).max() + 1e-9) * .55

def load_audio_mono(path):
    """Decode any audio/video file to 48 kHz mono float WITHOUT any processing other than the format conversion (resample, mono downmix)."""
    ff = shutil.which('ffmpeg')
    if not ff: raise RuntimeError('ffmpeg not found. Run setup/setup.sh (macOS/Linux) or setup/setup.ps1 (Windows).')
    p = subprocess.run([ff, '-v', 'error', '-i', str(path), '-vn', '-ac', '1', '-ar', str(SR), '-f', 's16le', '-'], capture_output=True)
    if p.returncode != 0: raise RuntimeError(f'ffmpeg could not read {path}: {p.stderr.decode(errors="replace")[-400:]}')
    x = np.frombuffer(p.stdout, dtype=np.int16).astype(np.float32) / 32768
    if len(x) == 0: raise RuntimeError(f'{path} has no audio')
    return x

def voice_duration(path): return len(load_audio_mono(path)) / SR

def mix(duration, voice=None, events=(), music_src='synth', music_gain=0.15, sfx_gain=0.22, out_path=None, warn=print):
    """events: [(time_s, kind, gain)]. Returns the path of a mono 48 kHz wav. The voice is placed first and never changed."""
    N = int(round(duration * SR)); vox = np.zeros(N, np.float32); bed = np.zeros(N, np.float32)
    if voice:
        v = load_audio_mono(voice)
        if len(v) > N + int(0.02 * SR): raise ValueError(f'the voice ({len(v) / SR:.2f}s) is longer than the video ({duration:.2f}s): extend the last scene')
        vox[:min(N, len(v))] = v[:N]
    for t, kind, g in sorted(events):
        x = sfx(kind, int(t * 1000) % 997 + 1) * g * sfx_gain; i = int(max(0, t) * SR)
        if i < N: bed[i:i + len(x)] += x[:N - i]
    if music_src not in (None, 'none'):
        m = music(duration + 1).mean(1) if music_src == 'synth' else load_audio_mono(music_src)
        m = m[:N] if len(m) >= N else np.pad(m, (0, N - len(m))); fo = np.minimum(1, (N - np.arange(N)) / SR / 2.0); bed += (m * fo * music_gain).astype(np.float32)
    vpeak = float(np.abs(vox).max()); total = float(np.abs(vox + bed).max()); ceiling = 0.97
    if total > ceiling:
        room = ceiling - vpeak
        if room <= 0: warn(f'warning: the voice alone peaks at {vpeak:.2f}; music and effects are muted where they would clip, the voice is left untouched'); bed *= 0
        else: bed *= min(1.0, room / max(float(np.abs(bed).max()), 1e-9))     # music and effects fit into the headroom; the voice keeps gain 1.0
        # a short bed peak can still push the sum over 0.97 when it coincides with a voice peak: reduce the bed further, never the voice
        while float(np.abs(vox + bed).max()) > 0.99 and float(np.abs(bed).max()) > 1e-4: bed *= 0.9
    mixd = vox + bed
    out_path = out_path or 'mix.wav'
    with wave.open(str(out_path), 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(np.rint(np.clip(mixd, -1, 1) * 32767).astype(np.int16).tobytes())
    return out_path
