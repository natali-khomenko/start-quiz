"""paper-collage-reel engine: brand tokens, paper look, video encoding."""
W, H = 1080, 1920
