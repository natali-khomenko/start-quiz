"""Local cut-outs (nothing is uploaded). Objects: background-removal model + alpha matting. Heads: person/skin/hair colour masks
measured from three numbers (centre x, top of hair, chin) so hair edges stay clean and the chin is rounded (head only, no neck)."""
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageOps

_sessions = {}
def _session(name):
    from rembg import new_session
    if name not in _sessions: _sessions[name] = new_session(name)
    return _sessions[name]

def _crop_to_content(im, pad=0, thr=24):
    """Crop to the visible content: faint glow or dust (alpha <= thr) must not stretch the box, or the layout checks would measure empty space."""
    bb = im.getchannel('A').point(lambda v: 255 if v > thr else 0).getbbox()
    return im.crop((max(0, bb[0] - pad), max(0, bb[1] - pad), bb[2] + pad, bb[3] + pad)) if bb else im

def cut_object(img, model='isnet-general-use', matting=True, max_side=2000):
    """Cut one object from a photo on a plain-ish background. Returns RGBA cropped to the object."""
    from rembg import remove
    img = img.convert('RGB')
    if max(img.size) > max_side: img.thumbnail((max_side, max_side), Image.LANCZOS)
    kw = dict(alpha_matting=True, alpha_matting_foreground_threshold=240, alpha_matting_background_threshold=15, alpha_matting_erode_size=8) if matting else {}
    return _crop_to_content(remove(img, session=_session(model), **kw))

def person_mask(img):
    """Soft person mask (human segmentation model), same size as img, uint8."""
    from rembg import remove
    return np.array(remove(img.convert('RGB'), session=_session('u2net_human_seg'), only_mask=True))

def mirror(img): return ImageOps.mirror(img)

def grid_preview(img, out, step=100, max_side=1100):
    """Photo with a labelled coordinate grid (original pixel units) so the three head landmarks can be read off by eye."""
    s = min(1.0, max_side / max(img.size)); im = img.convert('RGB').resize((int(img.width * s), int(img.height * s)), Image.LANCZOS); d = ImageDraw.Draw(im)
    for v in range(0, img.width, step): x = v * s; d.line([(x, 0), (x, im.height)], fill=(255, 0, 80), width=1); d.text((x + 3, 3), str(v), fill=(255, 0, 80))
    for v in range(0, img.height, step): y = v * s; d.line([(0, y), (im.width, y)], fill=(0, 120, 255), width=1); d.text((3, y + 3), str(v), fill=(0, 120, 255))
    im.save(out); return out

def auto_landmarks(img):
    """First guess of the three landmarks from a frontal-face detector (scikit-image). Always verify on the gallery.
    Returns {'cx','top_y','chin_y'} in original pixels, or None if no face is found."""
    from skimage.feature import Cascade
    from skimage import data
    g = np.array(ImageOps.grayscale(img)).astype(float) / 255; s = min(1.0, 800 / max(g.shape)); gi = np.array(Image.fromarray((g * 255).astype('uint8')).resize((int(g.shape[1] * s), int(g.shape[0] * s)))) 
    det = Cascade(data.lbp_frontal_face_cascade_filename())
    hits = det.detect_multi_scale(img=gi, scale_factor=1.15, step_ratio=1, min_size=(int(60), int(60)), max_size=(gi.shape[1], gi.shape[0]))
    if not hits: return None
    b = max(hits, key=lambda h: h['width'] * h['height']); x, y, w, h = b['c'] / s, b['r'] / s, b['width'] / s, b['height'] / s
    return {'cx': x + w / 2, 'top_y': y - 0.55 * h, 'chin_y': y + 1.02 * h}

def cut_head(img, lm, hair='auto', size=1390, return_meta=False):
    """Head-only cut-out with a rounded chin. lm = {'cx','top_y','chin_y'} (+ optional overrides) in original pixels.
    hair='dark' assumes dark hair (colour mask); hair='person' uses the person-segmentation mask for any hair colour;
    hair='auto' (default) measures how dark the hair region is and picks one of the two. With return_meta=True also returns
    {'axis_x': position of the face axis as a fraction of the cut-out width, 'hair': mode used}; save it as a .json next to the png."""
    from scipy import ndimage as ndi
    from skimage import morphology
    head_h = lm['chin_y'] - lm['top_y']; R = size / head_h
    im = img.convert('RGB').resize((int(img.width * R), int(img.height * R)), Image.LANCZOS)
    f = lambda v: v * R
    CX, TOP, CHIN = int(f(lm['cx'])), int(f(lm['top_y'])), int(f(lm['chin_y']))
    EAR = int(f(lm.get('ear_y', lm['top_y'] + 0.58 * head_h))); NECK = int(f(lm.get('neck_y', lm['chin_y'] + 0.105 * head_h)))
    NHALF = int(f(lm.get('neck_half', 0.128 * head_h))); LS = int(f(lm.get('face_half', 0.32 * head_h))); LH = int(f(lm.get('hair_half', 0.31 * head_h))); SKT = int(f(lm.get('skin_top', lm['top_y'] + 0.27 * head_h)))
    q = size / 1390.0; pad = int(400 * q); im = ImageOps.expand(im, pad, fill=(255, 255, 255)); CX += pad; TOP += pad; CHIN += pad; EAR += pad; NECK += pad; SKT += pad
    x0, y0 = int(CX - 700 * q), int(TOP - 200 * q); im = im.crop((x0, y0, x0 + int(1400 * q), y0 + int(2150 * q))); CX -= x0; EAR -= y0; CHIN -= y0; NECK -= y0; SKT -= y0; TOP -= y0
    rgb = np.array(im).astype(int); ycc = np.array(im.convert('YCbCr')).astype(int); H, W = rgb.shape[:2]; yy, xx = np.mgrid[:H, :W]; dx = np.abs(xx - CX); lum = rgb.mean(-1)
    skin = (ycc[..., 1] > 78) & (ycc[..., 1] < 135) & (ycc[..., 2] > 132) & (ycc[..., 2] < 182) & (ycc[..., 0] > 70)
    t = np.clip((yy - EAR) / max(1, CHIN - EAR), 0, 1)                      # the jaw narrows from the ears to the chin: keeps sofa/pillow out
    skin &= (dx < LS * (1 - 0.4 * t)) & (yy < NECK) & (yy > SKT) & ~((yy > CHIN) & (dx > NHALF))
    skin = ndi.binary_fill_holes(morphology.binary_closing(skin, morphology.disk(16)))
    lab, c = ndi.label(skin)
    if c == 0: raise ValueError('no skin found near the landmarks: check cx/top_y/chin_y on the grid preview')
    skin = lab == (1 + np.argmax(ndi.sum(skin, lab, range(1, c + 1))))
    skull = (((xx - CX) / (LH * 1.15)) ** 2 + ((yy - EAR) / max(1.0, EAR - TOP)) ** 2) <= 1     # rounded top: drops wall, shelf or flag pieces above the hair
    if hair == 'auto':
        reg = skull & (yy < SKT) & (yy >= TOP) & ~skin; dark = float((lum[reg] < 100).mean()) if reg.any() else 0.0
        hair = 'dark' if dark >= 0.35 else 'person'
    if hair == 'person':
        pm = np.array(Image.fromarray(person_mask(im)).resize((W, H))) > 128
        hr = pm & (yy < EAR) & (dx < LH)
    else: hr = (lum < 100) & (yy < EAR) & (dx < LH)
    hr &= skull
    m = skin | hr
    m = ndi.binary_fill_holes(morphology.binary_closing(m, morphology.disk(24))); m = morphology.binary_opening(m, morphology.disk(10))
    lab, c = ndi.label(m); m = lab == (1 + np.argmax(ndi.sum(m, lab, range(1, c + 1))))
    ey = CHIN - int(0.25 * size); low = yy > ey                              # HEAD ONLY: rounded chin, no neck
    rx, ry = 0.268 * size, 0.26 * size
    m &= ~low | ((((xx - CX) / rx) ** 2 + ((yy - ey) / ry) ** 2) <= 1); m &= yy < NECK
    a = Image.fromarray((m * 255).astype('uint8')).filter(ImageFilter.GaussianBlur(1.8))
    out = Image.fromarray(np.clip(rgb, 0, 255).astype('uint8')).convert('RGBA'); out.putalpha(a)
    bb = out.getchannel('A').getbbox(); res = out.crop(bb)
    if return_meta: return res, {'axis_x': round((CX - bb[0]) / (bb[2] - bb[0]), 4), 'hair': hair}
    return res

def gallery(files, out, cols=4, cell=420):
    """Contact sheet of cut-outs on three contrasting backgrounds (light, dark, pink): reveals leftover background and rough edges."""
    files = list(files); cols = max(1, min(cols, len(files))); rows = (len(files) + cols - 1) // cols; sheet = Image.new('RGB', (cols * cell, rows * cell * 3 // 1), 'white')
    bgs = [(245, 245, 245), (40, 28, 26), (244, 160, 190)]
    for i, fp in enumerate(files):
        im = Image.open(fp).convert('RGBA'); s = min((cell - 20) / im.width, (cell - 20) / im.height); im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
        for k, col in enumerate(bgs):
            tile = Image.new('RGB', (cell, cell), col); tile.paste(im, ((cell - im.width) // 2, (cell - im.height) // 2), im)
            ImageDraw.Draw(tile).text((6, 6), Path(fp).stem, fill=(255, 0, 80)); sheet.paste(tile, ((i % cols) * cell, (i // cols) * cell * 3 + k * cell))
    sheet.save(out); return out
