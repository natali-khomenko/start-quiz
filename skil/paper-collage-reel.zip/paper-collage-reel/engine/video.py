"""ffmpeg helpers: locate ffmpeg, encode a frame folder (+ optional audio) to H.264 mp4, probe results."""
import json, shutil, subprocess
from pathlib import Path

def ffmpeg_path():
    p = shutil.which('ffmpeg')
    if not p: raise RuntimeError('ffmpeg not found. Run setup/setup.sh (macOS/Linux) or setup/setup.ps1 (Windows).')
    return p

def probe(path):
    out = subprocess.run([shutil.which('ffprobe') or 'ffprobe', '-v', 'error', '-show_entries', 'stream=width,height,codec_type,duration:format=duration', '-of', 'json', str(path)], capture_output=True, text=True, check=True).stdout
    j = json.loads(out); v = next(s for s in j['streams'] if s['codec_type'] == 'video')
    return {'width': v['width'], 'height': v['height'], 'duration': float(j['format']['duration']), 'has_audio': any(s['codec_type'] == 'audio' for s in j['streams'])}

def encode(frames_dir, out_path, fps=12, out_fps=24, audio=None):
    cmd = [ffmpeg_path(), '-v', 'error', '-y', '-framerate', str(fps), '-i', str(Path(frames_dir) / 'f%05d.png')]
    if audio: cmd += ['-i', str(audio)]
    cmd += ['-r', str(out_fps), '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18']
    if audio: cmd += ['-c:a', 'aac', '-b:a', '192k', '-shortest']
    subprocess.run(cmd + [str(out_path)], check=True); return Path(out_path)
