"""Paper look: crumpled sheets, torn edges, white cut-out border with shadow, labels, tape. Brand-agnostic."""
import math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops

def noise(size, scale, seed):
    rng = np.random.default_rng(seed); w, h = size
    a = rng.random((h // scale + 2, w // scale + 2)).astype('float32')
    return np.array(Image.fromarray((a * 255).astype('uint8')).resize((w, h), Image.BICUBIC)).astype('float32') / 255

def crumpled(size, base, seed=3, strength=26):
    """Crumpled-paper texture: layered noise lit by its own gradient (creases) plus fine grain."""
    n = sum(noise(size, s, seed + i) * k for i, (s, k) in enumerate([(160, .5), (70, .3), (26, .15), (9, .05)]))
    gy, gx = np.gradient(n * 6.0); shade = (gx * -0.7 + gy * -0.7) * strength * 10
    grain = (noise(size, 2, seed + 9) - .5) * 9
    arr = np.array(Image.new('RGB', size, base)).astype('float32') + shade[..., None] + grain[..., None]
    return Image.fromarray(arr.clip(0, 255).astype('uint8')).convert('RGBA')

def torn_poly(box, step=13, amp=5, seed=1):
    x0, y0, x1, y1 = box; r = random.Random(seed); pts = []
    for x in range(int(x0), int(x1), step): pts.append((x, y0 + r.uniform(-amp, amp)))
    for y in range(int(y0), int(y1), step): pts.append((x1 + r.uniform(-amp, amp), y))
    for x in range(int(x1), int(x0), -step): pts.append((x, y1 + r.uniform(-amp, amp)))
    for y in range(int(y1), int(y0), -step): pts.append((x0 + r.uniform(-amp, amp), y))
    return pts

def with_edge(img, outline=14, torn=True, shadow=(5, 9), blur=9, op=95, seed=2):
    """White paper border (optionally hand-torn) + soft shadow around any RGBA cut-out."""
    pad = outline + max(shadow) + blur * 2 + 6
    base = Image.new('RGBA', (img.width + pad * 2, img.height + pad * 2), (0, 0, 0, 0)); base.paste(img, (pad, pad), img)
    a = base.getchannel('A'); k = outline * 2 + 1
    edge = a.filter(ImageFilter.MaxFilter(k)).filter(ImageFilter.GaussianBlur(3))
    if torn:
        wob = Image.fromarray((noise(base.size, 7, seed) * 255).astype('uint8')).filter(ImageFilter.GaussianBlur(1))
        edge = ImageChops.add(edge, wob.point(lambda v: v // 3), 1, -40).point(lambda v: 255 if v > 150 else 0).filter(ImageFilter.GaussianBlur(1))
    sh = ImageChops.offset(edge, *shadow).filter(ImageFilter.GaussianBlur(blur)).point(lambda v: v * op // 255)
    out = Image.new('RGBA', base.size, (0, 0, 0, 0)); out.paste(Image.new('RGBA', base.size, (60, 30, 40, 255)), (0, 0), sh)
    out.paste(Image.new('RGBA', base.size, (255, 255, 255, 255)), (0, 0), edge); out.alpha_composite(base); return out

def sheet(size, color, seed=11, torn_seed=7):
    """A torn sheet of crumpled paper with a white border."""
    w, h = size; s = Image.new('RGBA', size, (0, 0, 0, 0)); m = Image.new('L', size, 0)
    ImageDraw.Draw(m).polygon(torn_poly((6, 6, w - 6, h - 6), 12, 4, torn_seed), fill=255)
    s.paste(crumpled(size, color, seed, 9), (0, 0), m); return with_edge(s, 18, True, (6, 12), 14, 100, 4)

def label(text, font, fill=(255, 255, 255), color=(40, 40, 40), pad=(34, 22), rot=0, accent=None, accent_color=(255, 61, 139), seed=5, spacing=0):
    """Torn paper label. accent=(start,end) draws that character range on an accent plate (use for ONE highlighted word)."""
    tmp = ImageDraw.Draw(Image.new('RGB', (10, 10)))
    def width(s): return sum(tmp.textlength(ch, font=font) + spacing for ch in s)
    gap = 16 if accent else 0
    tw = width(text) + 2 * gap; asc, desc = font.getmetrics(); th = asc + desc
    im = Image.new('RGBA', (int(tw + pad[0] * 2), int(th + pad[1] * 2)), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.polygon(torn_poly((2, 2, im.width - 2, im.height - 2), 11, 2.4, seed), fill=tuple(fill) + (255,))
    x = pad[0]
    for i, ch in enumerate(text):
        w = tmp.textlength(ch, font=font) + spacing
        if accent and i == accent[0]: x += gap
        if accent and i == accent[1]: x += gap
        if accent and accent[0] <= i < accent[1]:
            if i == accent[0]: d.rounded_rectangle([x - 14, pad[1] - 2, x + width(text[accent[0]:accent[1]]) + 10, pad[1] + th - 2], 14, fill=tuple(accent_color) + (255,))
            d.text((x, pad[1]), ch, font=font, fill=(255, 255, 255, 255))
        else: d.text((x, pad[1]), ch, font=font, fill=tuple(color) + (255,))
        x += w
    return with_edge(im, 0, False, (3, 6), 6, 70).rotate(rot, expand=True, resample=Image.BICUBIC)

def tape(w=250, h=70, rot=-30, color=(236, 222, 206)):
    im = Image.new('RGBA', (w, h), tuple(color) + (190,)); m = Image.new('L', (w, h), 0)
    ImageDraw.Draw(m).polygon(torn_poly((0, 0, w, h), 7, 3, 9), fill=255)
    out = Image.new('RGBA', (w, h), (0, 0, 0, 0)); out.paste(im, (0, 0), m)
    return out.rotate(rot, expand=True, resample=Image.BICUBIC)

def heart(size, color):
    """Procedural paper heart (no external file)."""
    s = 4; n = size * s; im = Image.new('RGBA', (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    pts = [((16 * math.sin(t) ** 3), -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))) for t in np.linspace(0, 2 * math.pi, 200)]
    k = n / 36.0; d.polygon([(n / 2 + x * k, n / 2.2 + y * k) for x, y in pts], fill=tuple(color) + (255,))
    return im.crop(im.getbbox()).resize((size, int(size * 0.92)), Image.LANCZOS)
