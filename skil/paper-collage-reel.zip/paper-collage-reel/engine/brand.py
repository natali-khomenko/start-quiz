"""Brand tokens from brand.yml: colours, fonts, safe zone. Nothing in the engine hard-codes a brand."""
import os
from pathlib import Path
import yaml
from PIL import ImageFont

ROOT = Path(__file__).resolve().parent.parent
FONT_DIR = ROOT / 'assets' / 'fonts'

def hex_to_rgb(h):
    h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

class Brand:
    def __init__(self, path=None):
        path = Path(path) if path else ROOT / 'presets' / 'default' / 'brand.yml'
        self.path = path; cfg = yaml.safe_load(path.read_text(encoding='utf-8'))
        self.name = cfg.get('name', path.parent.name)
        self.c = {k: hex_to_rgb(v) for k, v in cfg['colors'].items()}
        self.fonts = cfg['fonts']; self.safe = cfg.get('safe_zone', {'top': 250, 'bottom': 1400})
        self._cache = {}
    def color(self, name): return self.c[name]
    def font(self, role, size):
        """role: display | subtitle | label. Falls back to PIL's default font if the file is missing (and says so once)."""
        key = (role, size)
        if key in self._cache: return self._cache[key]
        spec = self.fonts[role]; f = Path(spec['file'])
        f = f if f.is_absolute() else FONT_DIR / f
        try:
            ft = ImageFont.truetype(str(f), size)
            try: ft.set_variation_by_axes([spec.get('weight', 700)])
            except Exception: pass
        except OSError:
            print(f'[brand] font not found: {f} -> using default font'); ft = ImageFont.load_default()
        self._cache[key] = ft; return ft
    def has_glyphs(self, role, text):
        """True if the font really draws every character (a missing glyph renders as the .notdef box, e.g. the hryvnia sign in some fonts)."""
        spec = self.fonts[role]; f = Path(spec['file']); f = f if f.is_absolute() else FONT_DIR / f
        try: ft = ImageFont.truetype(str(f), 48)
        except OSError: return False
        notdef = ft.getmask('\uffff'); nd = (notdef.size, bytes(notdef))
        for ch in set(text):
            if ch.isspace(): continue
            m = ft.getmask(ch)
            if m.getbbox() is None or (m.size, bytes(m)) == nd: return False
        return True
