"""YAML scene spec -> stop-motion layers -> frames, plus Scene.check() that enforces the measurable rules of MISTAKES.md.
Positions are 1080x1920 pixels of the CONTENT box (the paper edge and shadow are added around it, outside the box):
  x, y = top-left | center: [x, y] | bottom_center: [x, y]   (bottom_center for heroes and objects standing on something)
Timing is relative to the scene start: at (appears), until (disappears), kind: pop | appear | drop | slide_l | slide_r | rise | fly.
z: optional stacking order (default = list order). group: layers with the same group appear, jitter and move together
(use it for a hero and the body piece under its head: MISTAKES.md #10). The frame rate is fixed at 12 fps (stop-motion on twos in a 24 fps file)."""
import math, random, zlib
from pathlib import Path
import json, yaml
from PIL import Image
from . import W, H, paper, elements
from .brand import Brand

FPS = 12
MARGIN = 60
ARRIVAL = {'pop': 0.30, 'appear': 0.12, 'drop': 0.50, 'slide_l': 0.36, 'slide_r': 0.36, 'rise': 0.26}
CONTAINERS = {'plate', 'sheet', 'folder', 'burst'}

def ease_out_back(u, c=1.9): u -= 1; return 1 + (c + 1) * u ** 3 + c * u ** 2
def ease_out_cubic(u): return 1 - (1 - u) ** 3
def ease_out_bounce(u):
    if u < 1 / 2.75: return 7.5625 * u * u
    if u < 2 / 2.75: u -= 1.5 / 2.75; return 7.5625 * u * u + .75
    if u < 2.5 / 2.75: u -= 2.25 / 2.75; return 7.5625 * u * u + .9375
    u -= 2.625 / 2.75; return 7.5625 * u * u + .984375

def _norm(w): return ''.join(ch for ch in w.lower() if ch.isalnum())
def _find_word(words, key, near):
    """Start time of the spoken word that equals the key (whole normalised token, or the key is its stem), the occurrence nearest to `near`."""
    k = _norm(key); best = None
    for w in words:
        t = _norm(w['word'])
        if k and (t == k or (len(k) >= 4 and (t.startswith(k) or k.startswith(t) and len(t) >= 4))):
            if best is None or abs(w['start'] - near) < abs(best - near): best = w['start']
    return best

def sid(s): return zlib.crc32(str(s).encode()) & 0xffffffff        # stable across runs (python's hash() is randomised per process)

class Layer:
    def __init__(self, eid, imgs, pos, at, until, kind, spec, cycle='flap', pad=0, etype='', z=0, group=None):
        self.id, self.imgs, self.pos, self.at, self.until, self.kind, self.spec, self.cycle, self.pad, self.etype, self.z, self.group = eid, imgs, pos, at, until, kind, spec, cycle, pad, etype, z, group
        self.pose_pos = None; self.size = (imgs[0].width, imgs[0].height) if cycle != 'poses' else (imgs[0][1].width, imgs[0][1].height)
    def pose_index(self, t_rel):
        idx = 0
        for i, (at, _) in enumerate(self.imgs):
            if t_rel >= at: idx = i
        return idx
    def image(self, t_rel):
        if self.cycle == 'poses': return self.imgs[self.pose_index(t_rel)][1]
        if len(self.imgs) == 1: return self.imgs[0]
        step = 2 if self.cycle == 'beat' else 1                          # heart beats every 2 frames, wings flap every frame
        return self.imgs[int(t_rel * FPS / step + 1e-6) % len(self.imgs)]
    def params(self, t):
        d = t - self.at
        if d < 0 or (self.until is not None and t >= self.until): return None
        a, s, dx, dy = 1.0, 1.0, 0.0, 0.0; k = self.kind
        if k == 'pop': u = min(1, d / 0.30); s = .55 + .45 * ease_out_back(u); a = min(1, u * 4)
        elif k == 'appear': a = min(1, d / 0.12)
        elif k == 'drop': u = min(1, d / 0.50); dy = -(1 - ease_out_bounce(u)) * 560; a = min(1, u * 6)
        elif k in ('slide_l', 'slide_r'): u = min(1, d / 0.36); dx = (1 - ease_out_cubic(u)) * (-760 if k == 'slide_l' else 760); a = min(1, u * 5)
        elif k == 'rise': u = min(1, d / 0.26); dy = (1 - ease_out_cubic(u)) * 70; a = min(1, u * 3)
        elif k == 'fly':
            dur = float(self.spec.get('dur', 1.05)); u = min(1, d / dur); sx, sy = self.spec.get('from', [0, 200]); ox, oy = self.spec.get('out', [0, -1000])
            if u < .4: v = u / .4; e = ease_out_cubic(v); dx, dy = (1 - e) * sx, (1 - e) * sy + 9 * math.sin(d * 6.0) * e; s = .35 + .65 * ease_out_back(v, 1.4); a = min(1, v * 5)
            else: v = (u - .4) / .6; dx, dy = ox * v * v, oy * v * v + 9 * math.sin(d * 6.0)
        return a, s, dx, dy
    def arrival_end(self):
        if self.kind == 'fly': return self.at + float(self.spec.get('dur', 1.05))
        return self.at + ARRIVAL.get(self.kind, 0.3)

class Scene:
    def __init__(self, spec, brand, root, heroes):
        self.id = spec['id']; self.start = float(spec['start']); self.end = float(spec['end']); self.brand = brand; self.root = Path(root); self.spec = spec
        if self.end <= self.start: raise ValueError(f"scene {self.id}: end must be after start")
        self.bg = self._background(spec.get('background', {})); self.layers = []
        for i, e in enumerate(spec.get('elements', [])): self.layers.append(self._build(e, i, heroes))
        self.layers.sort(key=lambda L: L.z)                                  # stable: equal z keeps list order
    # ---- helpers
    def col(self, v):
        if isinstance(v, str) and v in self.brand.c: return self.brand.c[v]
        if isinstance(v, str) and v.startswith('#'):
            from .brand import hex_to_rgb; return hex_to_rgb(v)
        if isinstance(v, (list, tuple)): return tuple(v)
        return self.brand.c['dark']
    def _background(self, b):
        t = b.get('type', 'crumpled'); size = (W, H)
        if t == 'gingham': return elements.gingham(size, self.col(b.get('color', 'soft')), (255, 255, 255), int(b.get('cell', 72)))
        if t == 'sky': return elements.sky(size)
        if t == 'solid': return Image.new('RGBA', size, self.col(b.get('color', 'light')) + (255,))
        c = self.col(b.get('color', 'light')); return paper.crumpled(size, c, int(b.get('seed', 3)), 22 if self.brand.c['light'] == c else 12)
    def _content(self, e):
        t = e['type']; b = self.brand; w = e.get('w'); h = e.get('h')
        def fit(im):
            if w and h: im = im.resize((int(w), int(h)), Image.LANCZOS)
            elif w: im = im.resize((int(w), max(1, int(im.height * w / im.width))), Image.LANCZOS)
            elif h: im = im.resize((max(1, int(im.width * h / im.height)), int(h)), Image.LANCZOS)
            return im
        if t == 'image': return fit(Image.open(self.root / e['file']).convert('RGBA'))
        if t == 'sheet': return paper.sheet(tuple(e['size']), self.col(e.get('color', 'soft')), int(e.get('seed', 11)))
        if t == 'label':
            self._glyphs('label' if e.get('font') == 'label' else e.get('font', 'display'), e['text'], e)
            return paper.label(e['text'], b.font(e.get('font', 'display'), int(e.get('font_size', 60))), fill=self.col(e.get('fill', 'white')), color=self.col(e.get('color', 'dark')), rot=float(e.get('rot', 0)), pad=tuple(e.get('pad', (34, 22))))
        if t == 'tape': return paper.tape(int(e.get('w', 250)), int(e.get('h', 70)), float(e.get('rot', -30)))
        if t == 'plate': return elements.plate(int(e.get('r', 360)), self.col(e.get('rim', 'dark')))
        if t == 'fork': return elements.fork(int(e.get('h', 700)))
        if t == 'knife': return elements.knife(int(e.get('h', 720)))
        if t == 'folder': self._glyphs('display', e.get('label', ''), e); return elements.folder(int(e.get('w', 780)), int(e.get('h', 560)), e.get('label', ''), b.font('display', int(e.get('font_size', 120))), self.col('dark'))
        if t == 'bubble': self._glyphs('label', e['text'], e); return elements.bubble(e['text'], b.font('label', int(e.get('font_size', 46))), self.col(e.get('fill', 'soft')), self.col(e.get('color', 'dark')), e.get('tail', 'left'))
        if t == 'burst': return elements.burst(int(e.get('size', 900)), self.col(e.get('color', 'white')), int(e.get('points', 12)))
        if t == 'star': return elements.star(int(e.get('size', 200)), self.col(e.get('color', 'accent')))
        if t == 'note': return elements.note(int(e.get('size', 110)), self.col(e.get('color', 'dark')))
        raise ValueError(f"scene {self.id}: unknown element type '{t}'")
    def _glyphs(self, role, text, e):
        if text and not self.brand.has_glyphs(role, text): raise ValueError(f"scene {self.id}: font '{role}' has no glyph for some character in {text!r} (MISTAKES.md #15). Pick another font in brand.yml.")
    def _edge(self, im, e, default):
        o = int(e.get('edge', default)); torn = bool(e.get('torn', False)); sh = tuple(e.get('shadow', (5, 10)))
        if o <= 0 and not e.get('shadow'): return im, 0
        out = paper.with_edge(im, o, torn, sh, 9, 100, int(e.get('seed', 3))); return out, (out.width - im.width) // 2
    def _pos(self, e, cw, ch, pad):
        if 'center' in e: x, y = e['center'][0] - cw / 2, e['center'][1] - ch / 2
        elif 'bottom_center' in e: x, y = e['bottom_center'][0] - cw / 2, e['bottom_center'][1] - ch
        else: x, y = e.get('x', 0), e.get('y', 0)
        return int(x - pad), int(y - pad)
    def _build(self, e, i, heroes):
        eid = e.get('id', f'{self.id}-{i}'); at = float(e.get('at', 0.1)); t = e['type']; kind = e.get('kind', 'pop'); z = float(e.get('z', i)); group = e.get('group')
        until = float(e['until']) if e.get('until') is not None else None
        if until is not None and not (until > at): raise ValueError(f"{eid}: until ({until}) must be after at ({at})")
        if group: kind = 'appear'                                            # grouped layers never scale-pop (they would drift apart)
        mk = lambda imgs, pos, cycle='flap', pad=0, k=None: Layer(eid, imgs, pos, at, until, k or kind, e, cycle, pad, t, z, group)
        if t == 'caption':
            txt = e['text']; acc = e.get('accent'); rng = None
            if acc:
                if acc not in txt: raise ValueError(f"{eid}: accent '{acc}' is not inside the caption text '{txt}' (case-sensitive)")
                s0 = txt.index(acc); rng = (s0, s0 + len(acc))
            self._glyphs('subtitle', txt, e)
            im = paper.label(txt, self.brand.font('subtitle', int(e.get('font_size', 42))), color=self.col('dark'), accent=rng, accent_color=self.col('accent'), pad=(34, 20), rot=float(e.get('rot', -1)))
            return mk([im], ((W - im.width) // 2, int(e.get('y', self.brand.safe['bottom'] + 5))), k=e.get('kind', 'rise'))
        if t == 'hero':
            name = e['hero']; files = heroes[name]; hh = int(e.get('h', 320)); poses = sorted(e['poses'], key=lambda p: float(p['at']))
            keys = [(p['pose'], bool(p.get('mirror'))) for p in poses]
            if len(set(keys)) != len(keys): raise ValueError(f"{eid}: a pose (with the same mirror) is used twice: poses are scripted once each and the last one is held (MISTAKES.md #11)")
            if len(keys) > 5: raise ValueError(f"{eid}: more than 5 poses in one scene")
            ref = None; seq = []
            for p in poses:
                fp = self.root / files[p['pose']]; im = Image.open(fp).convert('RGBA'); meta = {}
                if fp.with_suffix('.json').exists(): meta = json.loads(fp.with_suffix('.json').read_text())
                if ref is None: ref = hh / im.height                         # ONE scale for every pose, so the head never changes size on a switch
                im = im.resize((max(1, int(im.width * ref)), max(1, int(im.height * ref))), Image.LANCZOS); frac = float(meta.get('axis_x', 0.5))
                if p.get('mirror'): im = im.transpose(Image.FLIP_LEFT_RIGHT); frac = 1 - frac
                ed, pad = self._edge(im, e, 11); seq.append((float(p['at']), ed, im.width, im.height, pad, frac))
            if 'bottom_center' in e: cx, cy = e['bottom_center']
            else: cx, cy = e['center'][0], e['center'][1] + seq[0][3] / 2
            pos = [(int(cx - frac * w_ - pad), int(cy - h_ - pad)) for at_, ed, w_, h_, pad, frac in seq]          # anchored on the face axis, not the bbox centre
            L = mk([(a_[0], a_[1]) for a_ in seq], pos[0], 'poses', seq[0][4], k=e.get('kind', 'appear')); L.pose_pos = pos; L.content = (seq[0][2], seq[0][3]); return L
        if t == 'heart':
            from .paper import heart
            base = int(e.get('size', 200)); sizes = [base] + ([int(base * 1.18)] if e.get('beat') else [])
            cont = [heart(s, self.col(e.get('color', 'accent'))) for s in sizes]; cw, ch = cont[-1].size; canvas = []
            for c in cont:
                cv = Image.new('RGBA', (cw, ch), (0, 0, 0, 0)); cv.alpha_composite(c, ((cw - c.width) // 2, (ch - c.height) // 2)); canvas.append(paper.with_edge(cv, int(e.get('edge', 6)), False, (3, 6), 8, 100))
            pad = (canvas[0].width - cw) // 2; L = mk(canvas, self._pos(e, cw, ch, pad), 'beat', pad); L.content = (cw, ch); return L
        if t == 'bird':
            v = e.get('colors', {}); body = self.col(v.get('body', 'white')); wing = self.col(v.get('wing', 'dark')); belly = self.col(v.get('belly', 'soft')); size = int(e.get('size', 300))
            flip = bool(e['flip']) if 'flip' in e else (e.get('out', [0, -1000])[0] < 0)     # the beak points right, so a bird flying left is flipped
            frames = []
            for fl in (0, 1):
                bi = elements.cute_bird(body, wing, belly, size, fl, flip, self.col('dark')); ed, pad = self._edge(bi, e, 10); frames.append(ed)
            cw, ch = frames[0].width - 2 * pad, frames[0].height - 2 * pad; L = mk(frames, self._pos(e, cw, ch, pad), 'flap', pad); L.content = (cw, ch); return L
        cont = self._content(e)
        if 'rot' in e and t == 'image': cont = cont.rotate(float(e['rot']), expand=True, resample=Image.BICUBIC)
        ed, pad = self._edge(cont, e, 8 if t == 'image' else 0); L = mk([ed], self._pos(e, cont.width, cont.height, pad), 'flap', pad); L.content = cont.size; return L
    # ---- rules that can be measured (MISTAKES.md). Each violation starts with a [code] that can be passed to --skip.
    def check(self, words=None):
        out = []; dur = self.end - self.start; items = [L for L in self.layers if L.etype != 'caption']
        V = lambda code, msg: out.append(f"[{code}] {self.id}: {msg}")
        n = sum(1 for L in items if L.etype not in ('tape', 'burst'))
        if n > 6: V('count', f"{n} elements, more than 6 (MISTAKES #6)")
        last = max([L.arrival_end() for L in items if L.cycle != 'beat'] + [0.0]); idle = dur - last
        if last > 0.5 * dur + 0.05 and last > 0.8: V('arrival', f"the last element finishes arriving at {last:.2f}s, later than the first half of the {dur:.2f}s scene (MISTAKES #5)")
        if idle < 0.8: V('hold', f"the finished picture holds only {max(idle, 0):.2f}s (needs 0.8s or more, MISTAKES #5)")
        for L in self.layers:
            if L.until is not None and dur - 0.3 < L.until < dur: V('exit-late', f"{L.id} disappears in the last 0.3 s of the scene")
        boxes = []
        for L in items:
            if L.kind == 'fly' or L.spec.get('bleed') or L.etype in ('sheet', 'burst', 'tape'): continue
            cw, ch = getattr(L, 'content', L.size); x, y = (L.pose_pos[0] if L.pose_pos else L.pos); x += L.pad; y += L.pad
            if x < MARGIN or y < MARGIN or x + cw > W - MARGIN or y + ch > H - MARGIN: V('margin', f"{L.id} content box ({int(x)},{int(y)},{int(x + cw)},{int(y + ch)}) is closer than {MARGIN}px to the frame edge (MISTAKES #13); add 'bleed: true' only if deliberate")
            boxes.append((L, (x, y, x + cw, y + ch)))
        for i, (a, ba) in enumerate(boxes):
            for b, bb in boxes[i + 1:]:
                if a.group and a.group == b.group: continue
                if a.etype in CONTAINERS or b.etype in CONTAINERS: continue
                ix = max(0, min(ba[2], bb[2]) - max(ba[0], bb[0])); iy = max(0, min(ba[3], bb[3]) - max(ba[1], bb[1])); small = min((ba[2] - ba[0]) * (ba[3] - ba[1]), (bb[2] - bb[0]) * (bb[3] - bb[1]))
                if small and ix * iy / small > 0.15: V('overlap', f"{a.id} overlaps {b.id} ({int(100 * ix * iy / small)}% of the smaller one); group them or move one (MISTAKES #6)")
        cb = self.brand.safe.get('caption_bottom', 1540)   # the label's own shadow margin is 24 px
        for L in self.layers:
            if L.etype != 'caption': continue
            if L.pos[1] + L.size[1] - 24 > cb: V('caption-zone', f"{L.id} caption bottom is below y={cb} (brand.yml safe_zone.caption_bottom)")
            vis = (L.until if L.until is not None else dur) - L.at; nwords = len(L.spec['text'].split())
            if vis > 0 and nwords / vis > 3.0: V('reading-speed', f"{L.id} caption has {nwords} words visible for {vis:.1f}s (more than 3 words/s, MISTAKES #4)")
            w = L.spec.get('word')
            if w and words:
                ws = _find_word(words, w, self.start + L.at)
                if ws is None: V('caption-word', f"{L.id}: word '{w}' not found in the transcript near this scene")
                elif self.start + L.at < ws - 0.05: V('caption-early', f"{L.id} appears {ws - (self.start + L.at):.2f}s before the word '{w}' is spoken (MISTAKES #3)")
        groups = {}
        for L in items:
            if L.group: groups.setdefault(L.group, []).append(L)
        for g, ls in groups.items():
            heroes = [L for L in ls if L.etype == 'hero']; bodies = [L for L in ls if L.etype != 'hero']
            for hL in heroes:
                hx, hy = hL.pose_pos[0]; hb = hy + hL.pad + hL.content[1]
                for bL in bodies:
                    gap = (bL.pos[1] + bL.pad) - hb
                    if gap > 10: V('head-gap', f"group '{g}': the head ends {int(gap)}px above the body piece {bL.id} (must touch or overlap, gap 10px or less, MISTAKES #10)")
        return out
    # ---- rendering
    def frame(self, t_abs):
        t = t_abs - self.start; f = self.bg.copy(); fi = int(t_abs * FPS + 1e-6)
        for L in self.layers:
            p = L.params(t)
            if p is None: continue
            a, s, dx, dy = p; img = L.image(t); pos = L.pose_pos[L.pose_index(t)] if L.cycle == 'poses' else L.pos
            r = random.Random(sid((L.group or L.id, fi))); big = img.width >= 0.7 * W; jit = 1 if big else 2
            ang = 0 if L.group else ((r.uniform(-.3, .3) if big else r.uniform(-.8, .8)) if a >= 1 else 0); jx, jy = r.randint(-jit, jit), r.randint(-jit, jit)
            w, h = img.size; cx, cy = pos[0] + w / 2, pos[1] + h / 2; im = img
            if s != 1: im = im.resize((max(1, int(w * s)), max(1, int(h * s))), Image.BILINEAR)
            if ang: im = im.rotate(ang, expand=True, resample=Image.BILINEAR)
            if a < 1: al = im.getchannel('A').point(lambda v: int(v * a)); im = im.copy(); im.putalpha(al)
            x, y = int(cx - im.width / 2 + dx + jx), int(cy - im.height / 2 + dy + jy)
            if x >= W or y >= H or x + im.width <= 0 or y + im.height <= 0: continue
            sx, sy = max(0, -x), max(0, -y); ex, ey = min(im.width, W - x), min(im.height, H - y); f.alpha_composite(im.crop((sx, sy, ex, ey)), (x + sx, y + sy))
        return f

class Spec:
    def __init__(self, path):
        self.path = Path(path); self.root = self.path.parent; cfg = yaml.safe_load(self.path.read_text(encoding='utf-8'))
        bp = cfg.get('brand'); self.brand = Brand((self.root / bp) if bp and not Path(bp).is_absolute() else bp) if bp else Brand()
        self.heroes = cfg.get('heroes', {}); self.scenes = [Scene(s, self.brand, self.root, self.heroes) for s in cfg['scenes']]
    def scene(self, sid_): return next(s for s in self.scenes if s.id == sid_)
    def check(self, words=None, wipe=0.18):
        out = [v for s in self.scenes for v in s.check(words)]; sc = sorted(self.scenes, key=lambda s: s.start)
        ids = [s.id for s in sc]
        if len(set(ids)) != len(ids): out.append('[timeline] scene ids are not unique')
        if sc and sc[0].start > 0.05: out.append(f'[timeline] the first scene starts at {sc[0].start}s, not 0 (the video would open on bare paper)')
        for a, b in zip(sc, sc[1:]):
            if abs(a.end - b.start) > 0.02: out.append(f'[timeline] scene {a.id} ends at {a.end} but {b.id} starts at {b.start}: scenes must be contiguous')
            if words and b.spec.get('transition') != 'cut':
                for w in words:
                    if w['start'] < b.start + wipe / 2 and w['end'] > b.start - wipe / 2: out.append(f"[wipe-word] the cut before {b.id} at {b.start}s falls on the spoken word '{w['word']}' ({w['start']}-{w['end']}); move the cut into the silence (MISTAKES #2, #7)"); break
        return out
