"""Render a spec to mp4: rule gate -> frames (12 fps, torn-paper wipes <= 0.18 s) -> mix (voice untouched, SFX, music) -> H.264 at 24 fps."""
import math, random, shutil, tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
from . import W, H, sound, video
from .scene import Spec, FPS

WIPE = 0.18

def _strip():
    w = 70; m = Image.new('L', (w, H), 0); r = random.Random(5)
    ImageDraw.Draw(m).polygon([(w, 0)] + [(34 + r.uniform(-9, 9), y) for y in range(0, H + 24, 24)] + [(w, H)], fill=255)
    sh = m.filter(ImageFilter.GaussianBlur(10)).point(lambda v: v // 3); out = Image.new('RGBA', (w + 40, H), (0, 0, 0, 0))
    out.paste(Image.new('RGBA', (w, H), (60, 30, 40, 255)), (-14, 0), sh); out.paste(Image.new('RGBA', (w, H), (255, 255, 255, 255)), (0, 0), m); return out
STRIP = None

def sample(scenes, t):
    """Frame at time t. The wipe is a window [start - WIPE/2, start + WIPE/2] around each cut: the outgoing scene stays underneath until the window ends,
    the incoming scene is drawn from its own first frame (never before its start, so it is not bare paper) and uncovered by the torn strip.
    A scene with `transition: cut` gets a hard cut."""
    global STRIP
    cur = 0
    for i, s in enumerate(scenes):
        half = WIPE / 2 if i > 0 and s.spec.get('transition') != 'cut' else 0
        if t >= s.start + half - 1e-6: cur = i
    fr = scenes[cur].frame(t)
    if cur + 1 < len(scenes):
        nxt = scenes[cur + 1]
        if nxt.spec.get('transition') != 'cut' and t >= nxt.start - WIPE / 2 - 1e-6:
            u = min(1.0, max(0.0, (t - (nxt.start - WIPE / 2)) / WIPE)); u = math.floor(u * 4 + 1e-6) / 4 if u < 1 else 1; ex = int(W * (1 - u))
            if ex < W:
                STRIP = STRIP or _strip(); new = nxt.frame(max(t, nxt.start))
                fr.alpha_composite(new.crop((ex, 0, W, H)), (ex, 0))
                if 0 < ex < W: fr.alpha_composite(STRIP, (max(0, ex - 34), 0))
    return fr

def sfx_events(spec_cfg, scenes):
    ev = []; mode = spec_cfg.get('sfx', 'none')
    for s in scenes:
        for e in s.spec.get('sfx', []) or []: ev.append((s.start + float(e['at']), e['kind'], float(e.get('gain', .5))))
        if mode == 'auto':
            for L in s.layers:
                if L.etype in ('hero', 'heart', 'folder', 'plate') and L.kind != 'fly': ev.append((s.start + L.at, 'pop', .5))
                if L.kind == 'fly': ev.append((s.start + L.at, 'whoosh', .35))
    return ev

CODES = ('count', 'arrival', 'hold', 'exit-late', 'margin', 'overlap', 'caption-zone', 'reading-speed', 'caption-early', 'caption-word', 'head-gap', 'timeline', 'wipe-word')

def _skipped(v, skip):
    """skip items are `code` (all scenes) or `code:scene-id` (one scene only)."""
    code = v[1:v.index(']')]; scene = v[v.index('] ') + 2:].split(':')[0].split(' ')[0]
    return any(sk == code or sk == f'{code}:{scene}' for sk in skip)

def render(spec_path, out_path, voice=None, music='synth', skip=(), words=None, keep_frames=None, force=False, progress=print):
    import hashlib, json, subprocess, yaml
    for sk in skip:
        if sk.split(':')[0] not in CODES: raise ValueError(f"unknown skip code '{sk}'. Known codes: {', '.join(CODES)}")
    out_path = Path(out_path)
    if out_path.exists() and not force: raise FileExistsError(f'{out_path} already exists. Use a new name (-v2, -v3: keep every version) or pass --force.')
    spec = Spec(spec_path); allv = spec.check(words); bad = [v for v in allv if not _skipped(v, skip)]; skipped = [v for v in allv if _skipped(v, skip)]
    if bad: raise RuleViolations(bad)
    scenes = sorted(spec.scenes, key=lambda s: s.start); total = max(s.end for s in scenes)
    if voice:
        vd = sound.voice_duration(voice)
        if vd > total + 0.02: raise ValueError(f'the voice is {vd:.2f}s but the last scene ends at {total:.2f}s: extend the last scene (the voice would be cut)')
    n = int(math.ceil(total * FPS - 1e-6)); dur = n / FPS
    work = Path(keep_frames) if keep_frames else Path(tempfile.mkdtemp()); frames = work / 'frames'
    try:
        shutil.rmtree(frames, ignore_errors=True); frames.mkdir(parents=True)
        for k in range(n):
            sample(scenes, k / FPS).convert('RGB').save(frames / f'f{k:05d}.png', compress_level=1)
            if k % 60 == 0: progress(f'frame {k}/{n}')
        cfg = yaml.safe_load(Path(spec_path).read_text(encoding='utf-8'))
        wav = sound.mix(dur, voice, sfx_events(cfg, scenes), music if music is not None else cfg.get('music', 'synth'), out_path=work / 'mix.wav', warn=progress)
        out = video.encode(frames, out_path, FPS, 24, wav)
    finally:
        if not keep_frames: shutil.rmtree(work, ignore_errors=True)
    ff = subprocess.run([video.ffmpeg_path(), '-version'], capture_output=True, text=True).stdout.splitlines()[:1]
    log = {'output': str(out), 'spec': str(spec_path), 'spec_sha1': hashlib.sha1(Path(spec_path).read_bytes()).hexdigest(), 'voice': str(voice) if voice else None, 'duration_s': dur, 'music': music, 'skipped_checks': skipped, 'ffmpeg': ff}
    Path(str(out) + '.log.json').write_text(json.dumps(log, ensure_ascii=False, indent=1), encoding='utf-8')
    return out

class RuleViolations(Exception):
    def __init__(self, items): self.items = items; super().__init__('Rule checks failed:\n  ' + '\n  '.join(items) + '\nFix them, or pass --skip <code> (or <code>:<scene-id>) for a specific check the user agreed to skip.')
